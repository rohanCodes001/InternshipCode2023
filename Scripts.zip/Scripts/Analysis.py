# -*- coding: utf-8 -*-
"""
Created on Tue Jun 20 14:25:58 2023

@author: shan594
"""

#Imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import joblib 
import os
import matplotlib.image as mpimg
import seaborn as sns
from collections import Counter

# Directories in which we load files.
directory_wo_SSA_Stats = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/100 GeoSpatial Stats/'
directory_w_SSA_Stats = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/100 GeoSpatial Stats SSA Pred/'
directory_w_All_Pred_Stats = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/100 GeoSpatial Stats All Pred/'

directory_wo_SSA_Stats_ctmass_conc = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/100 GeoSpatial Stats Conc and CTMass/'
directory_w_SSA_Stats_ctmass_conc = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/100 GeoSpatial Stats Conc and CTMass SSA Pred/'
directory_w_All_Pred_Stats_ctmass_conc = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/100 GeoSpatial Stats Conc and CTMass All/'

#%%
# Non-SSA predictors results.
# Finding which visulization has lowest mean RMSE.
temp_val_m = 1
mean_viz = ''
viz_file = ''
for filename in os.listdir(directory_wo_SSA_Stats):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_wo_SSA_Stats+filename)
        if(mean < temp_val_m):
            temp_val_m = mean
            mean_viz = directory_wo_SSA_Stats+filename
            viz_file = filename

# Finding which visulization has lowest median RMSE.
temp_val_me = 1
median_viz = ''
for filename in os.listdir(directory_wo_SSA_Stats):
    if filename.endswith("Median.joblib") and not filename.endswith("CI_Median.joblib"):
        median = joblib.load(directory_wo_SSA_Stats+filename)
        if(median < temp_val_me):
            temp_val_me = median
            median_viz = directory_wo_SSA_Stats+filename

# Finding which visulization has lowest standard deviation RMSE.
temp_val_sd = 1
standard_deviation_viz = ''
for filename in os.listdir(directory_wo_SSA_Stats):
    if filename.endswith("Standard_Deviation.joblib"):
        sd = joblib.load(directory_wo_SSA_Stats+filename)
        if(sd < temp_val_sd):
            temp_val_sd = sd
            standard_deviation_viz = directory_wo_SSA_Stats+filename            
            
# Obtaining most frequent features across all 100 geostatistical visulizations. 
fi = []
column = []
for filename in os.listdir(directory_wo_SSA_Stats):
    if filename.endswith("Boot_FI.joblib"):
        upper = joblib.load(directory_wo_SSA_Stats+filename)
        new_list = list(upper)
        index = new_list.index(max(upper))
        fi.append(max(upper)) 
    if filename.endswith("Feature_DF.joblib"):
        temp_col = joblib.load(directory_wo_SSA_Stats+filename)
        column.append(temp_col.iloc[:,index].name) 
counts_of_fi = Counter(column)

# Barplot of most frequent features across all 100 geostatistical visulizations. 
plt.figure(figsize=(20,20))
plt.bar([x for x in range(len(counts_of_fi.keys()))], counts_of_fi.values())
plt.title('Most important features for (Predictor/target combination #2)', fontsize = 15)
plt.ylabel('Number of distributions', fontsize = 15)
plt.xticks(np.arange(len(counts_of_fi.keys())), counts_of_fi.keys(), rotation = 90, fontsize = 15)

# Finding which geostatistical visulization had the highest mean RMSE.
temp_val_m_wr = 0
mean_viz_wr = ''
viz_file_wr = ''
for filename in os.listdir(directory_wo_SSA_Stats):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_wo_SSA_Stats+filename)
        if(mean > temp_val_m_wr):
            temp_val_m_wr = mean
            mean_viz_wr = directory_wo_SSA_Stats+filename
            viz_file_wr = filename
            
# Plotting all 100 geostatistical visulizations with the lowest and highest 
# mean RMSE labeled with blue and red colors, respectively.         
for filename in os.listdir(directory_wo_SSA_Stats):
    if filename.endswith("RMSE_Dist.joblib"):
        rmse = joblib.load(directory_wo_SSA_Stats+filename)
        if(filename[:10] == viz_file[:10]):
            sns.kdeplot(rmse, color = 'blue', label = 'Lowest RMSE distribution')
        elif(filename[:10] == viz_file_wr[:10]):
            sns.kdeplot(rmse, color = 'red', label = 'Highest RMSE distribution')
        else:
            sns.kdeplot(rmse, color = 'green', alpha = 0.3)
        plt.title("RMSE across 1000 bootstrap samples for each geostatistical visulization\n"
                  "(Predictor/target combination #2)")
        plt.xlabel("RMSE")
        plt.legend()

#%%            
# SSA predictors only results.
# Finding which visulization has lowest mean RMSE.
temp_val_m = 1
mean_viz = ''
viz_file = ''
for filename in os.listdir(directory_w_SSA_Stats):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_w_SSA_Stats+filename)
        if(mean < temp_val_m):
            temp_val_m = mean
            mean_viz = directory_w_SSA_Stats+filename
            viz_file = filename

# Finding which visulization has lowest median RMSE.
temp_val_me = 1
median_viz = ''
for filename in os.listdir(directory_w_SSA_Stats):
    if filename.endswith("Median.joblib") and not filename.endswith("CI_Median.joblib"):
        median = joblib.load(directory_w_SSA_Stats+filename)
        if(median < temp_val_me):
            temp_val_me = median
            median_viz = directory_w_SSA_Stats+filename

# Finding which visulization has lowest standard deviation RMSE.
temp_val_sd = 1
standard_deviation_viz = ''
for filename in os.listdir(directory_w_SSA_Stats):
    if filename.endswith("Standard_Deviation.joblib"):
        sd = joblib.load(directory_w_SSA_Stats+filename)
        if(sd < temp_val_sd):
            temp_val_sd = sd
            standard_deviation_viz = directory_w_SSA_Stats+filename            
        
# Obtaining most frequent features across all 100 geostatistical visulizations. 
fi = []
column = []
for filename in os.listdir(directory_w_SSA_Stats):
    if filename.endswith("Boot_FI.joblib"):
        upper = joblib.load(directory_w_SSA_Stats+filename)
        new_list = list(upper)
        index = new_list.index(max(upper))
        fi.append(max(upper)) 
    if filename.endswith("Feature_DF.joblib"):
        temp_col = joblib.load(directory_w_SSA_Stats+filename)
        column.append(temp_col.iloc[:,index].name) 
counts_of_fi = Counter(column)

# Barplot of most frequent features across all 100 geostatistical visulizations. 
plt.figure(figsize=(20,20))
plt.bar([x for x in range(len(counts_of_fi.keys()))], counts_of_fi.values())
plt.title('Most important features for (Predictor/target combination #3)', fontsize = 15)
plt.ylabel('Number of distributions', fontsize = 15)
plt.xticks(np.arange(len(counts_of_fi.keys())), counts_of_fi.keys(), rotation = 90, fontsize = 15)

# Finding which geostatistical visulization had the highest mean RMSE.
temp_val_m_wr = 0
mean_viz_wr = ''
viz_file_wr = ''
for filename in os.listdir(directory_w_SSA_Stats):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_w_SSA_Stats+filename)
        if(mean > temp_val_m_wr):
            temp_val_m_wr = mean
            mean_viz_wr = directory_w_SSA_Stats+filename
            viz_file_wr = filename

# Plotting all 100 geostatistical visulizations with the lowest and highest 
# mean RMSE labeled with blue and red colors, respectively.    
for filename in os.listdir(directory_w_SSA_Stats):
    if filename.endswith("RMSE_Dist.joblib"):
        rmse = joblib.load(directory_w_SSA_Stats+filename)
        if(filename[:10] == viz_file[:10]):
            sns.kdeplot(rmse, color = 'blue', label = 'Lowest RMSE distribution')
        elif(filename[:10] == viz_file_wr[:10]):
            sns.kdeplot(rmse, color = 'red', label = 'Highest RMSE distribution')
        else:
            sns.kdeplot(rmse, color = 'green', alpha = 0.3)
        plt.title("RMSE across 1000 bootstrap samples for each geostatistical visulization\n"
                  "(Predictor/target combination #3)")
        plt.xlabel("RMSE")
        plt.legend()
            
#%%
# All (SSA and original time-series) predictors results.
# Finding which geostatistical visulization had the lowest mean RMSE.
temp_val_m = 1
mean_viz = ''
viz_file = ''
for filename in os.listdir(directory_w_All_Pred_Stats):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_w_All_Pred_Stats+filename)
        if(mean < temp_val_m):
            temp_val_m = mean
            mean_viz = directory_w_All_Pred_Stats+filename
            viz_file = filename

# Finding which visulization has lowest median RMSE.
temp_val_me = 1
median_viz = ''
for filename in os.listdir(directory_w_All_Pred_Stats):
    if filename.endswith("Median.joblib") and not filename.endswith("CI_Median.joblib"):
        median = joblib.load(directory_w_All_Pred_Stats+filename)
        if(median < temp_val_me):
            temp_val_me = median
            median_viz = directory_w_All_Pred_Stats+filename

# Finding which visulization has lowest standard deviation RMSE.
temp_val_sd = 1
standard_deviation_viz = ''
for filename in os.listdir(directory_w_All_Pred_Stats):
    if filename.endswith("Standard_Deviation.joblib"):
        sd = joblib.load(directory_w_All_Pred_Stats+filename)
        if(sd < temp_val_sd):
            temp_val_sd = sd
            standard_deviation_viz = directory_w_All_Pred_Stats+filename            
          
# Obtaining most frequent features across all 100 geostatistical visulizations. 
fi = []
column = []
for filename in os.listdir(directory_w_All_Pred_Stats):
    if filename.endswith("Boot_FI.joblib"):
        upper = joblib.load(directory_w_All_Pred_Stats+filename)
        new_list = list(upper)
        index = new_list.index(max(upper))
        fi.append(max(upper)) 
    if filename.endswith("Feature_DF.joblib"):
        temp_col = joblib.load(directory_w_All_Pred_Stats+filename)
        column.append(temp_col.iloc[:,index].name) 
counts_of_fi = Counter(column)

# Barplot of most frequent features across all 100 geostatistical visulizations. 
plt.figure(figsize=(20,20))
plt.bar([x for x in range(len(counts_of_fi.keys()))], counts_of_fi.values())
plt.title('Most important features for (Predictor/target combination #1)', fontsize = 15)
plt.ylabel('Number of distributions', fontsize = 15)
plt.xticks(np.arange(len(counts_of_fi.keys())), counts_of_fi.keys(), rotation = 90, fontsize = 15)          
          
# Finding which geostatistical visulization had the highest mean RMSE.
temp_val_m_wr = 0
mean_viz_wr = ''
viz_file_wr = ''
for filename in os.listdir(directory_w_All_Pred_Stats):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_w_All_Pred_Stats+filename)
        if(mean > temp_val_m_wr):
            temp_val_m_wr = mean
            mean_viz_wr = directory_w_All_Pred_Stats+filename
            viz_file_wr = filename

# Plotting all 100 geostatistical visulizations with the lowest and highest 
# mean RMSE labeled with blue and red colors, respectively.   
for filename in os.listdir(directory_w_All_Pred_Stats):
    if filename.endswith("RMSE_Dist.joblib"):
        rmse = joblib.load(directory_w_All_Pred_Stats + filename)
        if(filename[:10] == viz_file[:10]):
            sns.kdeplot(rmse, color = 'blue', label = 'Lowest RMSE distribution')
        elif(filename[:10] == viz_file_wr[:10]):
            sns.kdeplot(rmse, color = 'red', label = 'Highest RMSE distribution')
        else:
            sns.kdeplot(rmse, color = 'green', alpha = 0.3)
        plt.title("RMSE across 1000 bootstrap samples for each geostatistical visulization\n" 
                  "(Predictor/target combination #1)")
        plt.xlabel("RMSE")
        plt.legend()

#%%            
# Non-SSA predictors results for conc and ctmass as target.
# Finding which geostatistical visulization had the lowest mean RMSE.
temp_val_m = 1
mean_viz = ''
viz_file = ''
# Finding which geostatistical visulization had the lowest mean.
for filename in os.listdir(directory_wo_SSA_Stats_ctmass_conc):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_wo_SSA_Stats_ctmass_conc+filename)
        if(mean < temp_val_m):
            temp_val_m = mean
            mean_viz = directory_wo_SSA_Stats_ctmass_conc+filename
            viz_file = filename
            
# Finding which visulization has lowest median RMSE.
temp_val_me = 1
median_viz = ''
for filename in os.listdir(directory_wo_SSA_Stats_ctmass_conc):
    if filename.endswith("Median.joblib") and not filename.endswith("CI_Median.joblib"):
        median = joblib.load(directory_wo_SSA_Stats_ctmass_conc+filename)
        if(median < temp_val_me):
            temp_val_me = median
            median_viz = directory_wo_SSA_Stats_ctmass_conc+filename

# Finding which visulization has lowest standard deviation RMSE.
temp_val_sd = 1
standard_deviation_viz = ''
for filename in os.listdir(directory_wo_SSA_Stats_ctmass_conc):
    if filename.endswith("Standard_Deviation.joblib"):
        sd = joblib.load(directory_wo_SSA_Stats_ctmass_conc + filename)
        if(sd < temp_val_sd):
            temp_val_sd = sd
            standard_deviation_viz = directory_wo_SSA_Stats_ctmass_conc + filename            
            

# Obtaining most frequent features across all 100 geostatistical visulizations. 
fi = []
column = []
for filename in os.listdir(directory_wo_SSA_Stats_ctmass_conc):
    if filename.endswith("Boot_FI.joblib"):
        upper = joblib.load(directory_wo_SSA_Stats_ctmass_conc+filename)
        new_list = list(upper)
        index = new_list.index(max(upper))
        fi.append(max(upper)) 
    if filename.endswith("Feature_DF.joblib"):
        temp_col = joblib.load(directory_wo_SSA_Stats_ctmass_conc+filename)
        column.append(temp_col.iloc[:,index].name) 
counts_of_fi = Counter(column)

# Barplot of most frequent features across all 100 geostatistical visulizations. 
plt.figure(figsize=(20,20))
plt.bar([x for x in range(len(counts_of_fi.keys()))], counts_of_fi.values())
plt.title('Most important features for (Predictor/target combination #5)', fontsize = 15)
plt.ylabel('Number of distributions', fontsize = 15)
plt.xticks(np.arange(len(counts_of_fi.keys())), counts_of_fi.keys(), rotation = 90, fontsize = 15)

# Finding which geostatistical visulization had the highest mean RMSE.
temp_val_m_wr = 0
mean_viz_wr = ''
viz_file_wr = ''
for filename in os.listdir(directory_wo_SSA_Stats_ctmass_conc):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_wo_SSA_Stats_ctmass_conc+filename)
        if(mean > temp_val_m_wr):
            temp_val_m_wr = mean
            mean_viz_wr = directory_wo_SSA_Stats_ctmass_conc+filename
            viz_file_wr = filename

# Plotting all 100 geostatistical visulizations with the lowest and highest 
# mean RMSE labeled with blue and red colors, respectively. 
for filename in os.listdir(directory_wo_SSA_Stats_ctmass_conc):
    if filename.endswith("RMSE_Dist.joblib"):
        rmse = joblib.load(directory_wo_SSA_Stats_ctmass_conc+filename)
        if(filename[:10] == viz_file[:10]):
            sns.kdeplot(rmse, color = 'blue', label = 'Lowest RMSE distribution')
        elif(filename[:10] == viz_file_wr[:10]):
            sns.kdeplot(rmse, color = 'red', label = 'Highest RMSE distribution')
        else:
            sns.kdeplot(rmse, color = 'green', alpha = 0.3)
        plt.title("RMSE across 1000 bootstrap samples for each geostatistical visulization\n"
                  "(Predictor/target combination #5)")
        plt.xlabel("RMSE")
        plt.legend()

#%%    
# SSA predictors results for conc and ctmass as target.
# Finding which geostatistical visulization had the lowest mean RMSE.
temp_val_m = 1
mean_viz = ''
viz_file = ''
for filename in os.listdir(directory_w_SSA_Stats_ctmass_conc):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_w_SSA_Stats_ctmass_conc+filename)
        if(mean < temp_val_m):
            temp_val_m = mean
            mean_viz = directory_w_SSA_Stats_ctmass_conc+filename
            viz_file = filename

# Finding which visulization has lowest median RMSE.
temp_val_me = 1
median_viz = ''
for filename in os.listdir(directory_w_SSA_Stats_ctmass_conc):
    if filename.endswith("Median.joblib") and not filename.endswith("CI_Median.joblib"):
        median = joblib.load(directory_w_SSA_Stats_ctmass_conc+filename)
        if(median < temp_val_me):
            temp_val_me = median
            median_viz = directory_w_SSA_Stats_ctmass_conc+filename

# Finding which visulization has lowest standard deviation RMSE.
temp_val_sd = 1
standard_deviation_viz = ''
for filename in os.listdir(directory_w_SSA_Stats_ctmass_conc):
    if filename.endswith("Standard_Deviation.joblib"):
        sd = joblib.load(directory_w_SSA_Stats_ctmass_conc + filename)
        if(sd < temp_val_sd):
            temp_val_sd = sd
            standard_deviation_viz = directory_w_SSA_Stats_ctmass_conc + filename            

# Obtaining most frequent features across all 100 geostatistical visulizations. 
fi = []
column = []
for filename in os.listdir(directory_w_SSA_Stats_ctmass_conc):
    if filename.endswith("Boot_FI.joblib"):
        upper = joblib.load(directory_w_SSA_Stats_ctmass_conc+filename)
        new_list = list(upper)
        index = new_list.index(max(upper))
        fi.append(max(upper)) 
    if filename.endswith("Feature_DF.joblib"):
        temp_col = joblib.load(directory_w_SSA_Stats_ctmass_conc+filename)
        column.append(temp_col.iloc[:,index].name) 
counts_of_fi = Counter(column)

# Barplot of most frequent features across all 100 geostatistical visulizations. 
plt.figure(figsize=(20,20))
plt.bar([x for x in range(len(counts_of_fi.keys()))], counts_of_fi.values())
plt.title('Most important features for (Predictor/target combination #6)', fontsize = 15)
plt.ylabel('Number of distributions', fontsize = 15)
plt.xticks(np.arange(len(counts_of_fi.keys())), counts_of_fi.keys(), rotation = 90, fontsize = 15)

# Finding which geostatistical visulization had the highest mean RMSE.
temp_val_m_wr = 0
mean_viz_wr = ''
viz_file_wr = ''
for filename in os.listdir(directory_w_SSA_Stats_ctmass_conc):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_w_SSA_Stats_ctmass_conc+filename)
        if(mean > temp_val_m_wr):
            temp_val_m_wr = mean
            mean_viz_wr = directory_w_SSA_Stats_ctmass_conc+filename
            viz_file_wr = filename

# Plotting all 100 geostatistical visulizations with the lowest and highest 
# mean RMSE labeled with blue and red colors, respectively. 
for filename in os.listdir(directory_w_SSA_Stats_ctmass_conc):
    if filename.endswith("RMSE_Dist.joblib"):
        rmse = joblib.load(directory_w_SSA_Stats_ctmass_conc+filename)
        if(filename[:10] == viz_file[:10]):
            sns.kdeplot(rmse, color = 'blue', label = 'Lowest RMSE distribution')
        elif(filename[:10] == viz_file_wr[:10]):
            sns.kdeplot(rmse, color = 'red', label = 'Highest RMSE distribution')
        else:
            sns.kdeplot(rmse, color = 'green', alpha = 0.1)
        plt.title("RMSE across 1000 bootstrap samples for each geostatistical visulization\n"
                  "(Predictor/target combination #6)")
        plt.xlabel("RMSE")
        plt.legend()

#%%
# All (SSA and original time-series) predictor results for conc and ctmass as target.
# Finding which geostatistical visulization had the lowest mean RMSE.
temp_val_m = 1
mean_viz = ''
viz_file = ''
for filename in os.listdir(directory_w_All_Pred_Stats_ctmass_conc):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_w_All_Pred_Stats_ctmass_conc+filename)
        if(mean < temp_val_m):
            temp_val_m = mean
            mean_viz = directory_w_All_Pred_Stats_ctmass_conc+filename
            viz_file = filename

# Finding which visulization has lowest median RMSE.
temp_val_me = 1
median_viz = ''
for filename in os.listdir(directory_w_All_Pred_Stats_ctmass_conc):
    if filename.endswith("Median.joblib") and not filename.endswith("CI_Median.joblib"):
        median = joblib.load(directory_w_All_Pred_Stats_ctmass_conc+filename)
        if(median < temp_val_me):
            temp_val_me = median
            median_viz = directory_w_All_Pred_Stats_ctmass_conc+filename

# Finding which visulization has lowest standard deviation RMSE.
temp_val_sd = 1
standard_deviation_viz = ''
for filename in os.listdir(directory_w_All_Pred_Stats_ctmass_conc):
    if filename.endswith("Standard_Deviation.joblib"):
        sd = joblib.load(directory_w_All_Pred_Stats_ctmass_conc + filename)
        if(sd < temp_val_sd):
            temp_val_sd = sd
            standard_deviation_viz = directory_w_All_Pred_Stats_ctmass_conc + filename            
            
# Obtaining most frequent features across all 100 geostatistical visulizations. 
fi = []
column = []
for filename in os.listdir(directory_w_All_Pred_Stats_ctmass_conc):
    if filename.endswith("Boot_FI.joblib"):
        upper = joblib.load(directory_w_All_Pred_Stats_ctmass_conc+filename)
        new_list = list(upper)
        index = new_list.index(max(upper))
        fi.append(max(upper)) 
    if filename.endswith("Feature_DF.joblib"):
        temp_col = joblib.load(directory_w_All_Pred_Stats_ctmass_conc+filename)
        column.append(temp_col.iloc[:,index].name) 
counts_of_fi = Counter(column)

# Barplot of most frequent features across all 100 geostatistical visulizations. 
plt.figure(figsize=(20,20))
plt.bar([x for x in range(len(counts_of_fi.keys()))], counts_of_fi.values())
plt.title('Most important features for (Predictor/target combination #4)', fontsize = 15)
plt.ylabel('Number of distributions', fontsize = 15)
plt.xticks(np.arange(len(counts_of_fi.keys())), counts_of_fi.keys(), rotation = 90, fontsize = 15)           

# Finding which geostatistical visulization had the highest mean RMSE.
temp_val_m_wr = 0
mean_viz_wr = ''
viz_file_wr = ''
for filename in os.listdir(directory_w_All_Pred_Stats_ctmass_conc):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_w_All_Pred_Stats_ctmass_conc+filename)
        if(mean > temp_val_m_wr):
            temp_val_m_wr = mean
            mean_viz_wr = directory_w_All_Pred_Stats_ctmass_conc+filename
            viz_file_wr = filename

# Plotting all 100 geostatistical visulizations with the lowest and highest 
# mean RMSE labeled with blue and red colors, respectively. 
for filename in os.listdir(directory_w_All_Pred_Stats_ctmass_conc):
    if filename.endswith("RMSE_Dist.joblib"):
        rmse = joblib.load(directory_w_All_Pred_Stats_ctmass_conc + filename)
        if(filename[:10] == viz_file[:10]):
            sns.kdeplot(rmse, color = 'blue', label = 'Lowest RMSE Distribution')
        elif(filename[:10] == viz_file_wr[:10]):
            sns.kdeplot(rmse, color = 'red', label = 'Highest RMSE Distribution')
        else:
            sns.kdeplot(rmse, color = 'green', alpha = 0.1)
        plt.title("RMSE across 1000 bootstrap samples for each geostatistical visulization\n"
                  "(Predictor/target combination #4)")
        plt.xlabel("RMSE")
        plt.legend()