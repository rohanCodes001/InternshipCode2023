
# -*- coding: utf-8 -*-
"""
Created on Wed Jun 28 14:31:57 2023

@author: shan594
"""

# Imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import joblib 
from datetime import datetime
from matplotlib import cm
from matplotlib.dates import DateFormatter
import matplotlib.dates as mdates
#from temp import SSA
import os
import math as math
import seaborn as sns
from sklearn import preprocessing
from sklearn.ensemble import RandomForestRegressor
from sklearn.tree import DecisionTreeRegressor
from sklearn.model_selection import train_test_split
from sklearn.utils import resample
from sklearn.metrics import mean_squared_error
import seaborn as sns
import scipy.stats as st
from scipy.spatial import distance
import geopandas as gp
import scipy.spatial as spatial
from sklearn.preprocessing import MinMaxScaler
from scipy.stats import skew, kurtosis
from sklearn.metrics import accuracy_score
import matplotlib.patches as mpatches
from matplotlib import cm
    
#%%
# Seasonal component data processing.
def seasonal_process_conc(directory, myData, namesofmyData, originalNineteenWells):
    """ Processes seasonal components of original time-series to return mean,
    median, standard deviation, skewness, and kurtosis of all 19 wells.
   
    Parameters
    ----------
    directory : string
       directory in which seasonal CCL4 concentration components are located.
    myData : list
       empty list that will contain the scaled seasonal CCL4 concentration 
       components after function executes.
    namesofmyData: list
       empty list that will contain the names of the 19 wells.
    originalNineteenWells: list
       list of 19 wells from the orginal time-series data joblib file. Used to 
       cross reference with name of well from the seasonal CCL4 concentration
       joblib file to ensure sure that the proper 19 wells' seasonal components
       are being processed.

    Returns
    -------
    seasonal_process_conc_df: Dataframe
       Contains mean, median, standard deviation, skewness, and kurtosis of all 
       19 wells' seasonal CCL4 concentration.
    """
    summeddata_seasonal_conc_mean = [] 
    summeddata_seasonal_conc_median = [] 
    summeddata_seasonal_conc_std = []
    summeddata_seasonal_conc_skewness = [] 
    summeddata_seasonal_conc_kurtosis = []
    for filename in os.listdir(directory):
        for well in range(0, len(originalNineteenWells)):
            if filename.endswith("Concentration.joblib"):
                if(filename.replace('-Concentration.joblib', '') == originalNineteenWells[well]):
                    temp_df = joblib.load(directory+filename)
                    temp_df = pd.DataFrame(temp_df.loc[:,temp_df.columns != 'F0'].sum(axis = 1), columns = ['Sum of Components'])
                    
                    # Scaling summed seasonal concentration vals between 0 and 1 here.
                    scaler = MinMaxScaler()               
                    temp_df = scaler.fit_transform(temp_df)      
                    temp_df = pd.DataFrame(temp_df.flatten())
                    myData.append(temp_df)
                    
                    # Getting the average of the seasonal components.
                    summeddata_seasonal_conc_mean.append(temp_df.mean(axis = 0).tolist())
                    # Getting median of seasonal components.
                    summeddata_seasonal_conc_median.append(temp_df.median(axis = 0).tolist())
                    # Getting std of seasonal components.
                    summeddata_seasonal_conc_std.append(temp_df.std(axis = 0).tolist()) 
                    # Getting skewness of seasonal components.
                    summeddata_seasonal_conc_skewness.append(skew(temp_df, axis = 0, bias=True).tolist())
                    # Getting kurtosis of seasonal components.
                    summeddata_seasonal_conc_kurtosis.append(kurtosis(temp_df, axis = 0, bias=True).tolist())
                    namesofmyData.append(filename[:-7])
    seasonal_process_conc_df = pd.DataFrame()
    seasonal_process_conc_df['Summed seasonal conc mean'] = summeddata_seasonal_conc_mean
    seasonal_process_conc_df['Summed seasonal conc median'] = summeddata_seasonal_conc_median
    seasonal_process_conc_df['Summed seasonal conc std'] = summeddata_seasonal_conc_std
    seasonal_process_conc_df['Summed seasonal conc skewness'] = summeddata_seasonal_conc_skewness
    seasonal_process_conc_df['Summed seasonal conc kurtosis'] = summeddata_seasonal_conc_kurtosis
    return seasonal_process_conc_df
    
    
def seasonal_process_ctmass(directory, myData_ctmass, namesofmyData_ctmass, originalNineteenWells):
    """ Processes seasonal components of original time-series to return mean,
    median, standard deviation, skewness, and kurtosis of all 19 wells.
   
    Parameters
    ----------
    directory : string
       directory in which seasonal CCL4 mass components are located.
    myData_ctmass : list
       empty list that will contain the scaled seasonal CCL4 mass 
       components after function executes.
    namesofmyData_ctmass: list
       empty list that will contain the names of the 19 wells.
    originalNineteenWells: list
       list of 19 wells from the orginal time-series data joblib file. Used to 
       cross reference with name of well from the seasonal CCL4 mass
       joblib file to ensure sure that the proper 19 wells' seasonal components
       are being processed.

    Returns
    -------
    seasonal_process_ctmass_df: Dataframe
       Contains mean, median, standard deviation, skewness, and kurtosis of all 
       19 wells' seasonal CCL4 mass.
    """
    summeddata_seasonal_ctmass_mean = [] 
    summeddata_seasonal_ctmass_median = [] 
    summeddata_seasonal_ctmass_std = []
    summeddata_seasonal_ctmass_skewness = [] 
    summeddata_seasonal_ctmass_kurtosis = []
    for filename in os.listdir(directory):
        for well in range(0, len(originalNineteenWells)):
            if filename.endswith("CTMass.joblib"):
                if(filename.replace('-CTMass.joblib', '') == originalNineteenWells[well]):
                    temp_df = joblib.load(directory+filename)
                    temp_df = pd.DataFrame(temp_df.loc[:,temp_df.columns != 'F0'].sum(axis = 1), columns = ['Sum of Components'])
                
                    # Scaling summed seasonal ctmass vals between 0 and 1 here.
                    scaler = MinMaxScaler()               
                    temp_df = scaler.fit_transform(temp_df)
                    temp_df = pd.DataFrame(temp_df.flatten())
                    myData_ctmass.append(temp_df)
                    
                    # Getting the average of the seasonal components.
                    summeddata_seasonal_ctmass_mean.append(temp_df.mean(axis = 0).tolist())  
                    # Getting median of seasonal components.
                    summeddata_seasonal_ctmass_median.append(temp_df.median(axis = 0).tolist()) 
                    # Getting std of seasonal components.
                    summeddata_seasonal_ctmass_std.append(temp_df.std(axis = 0).tolist()) 
                    # Getting skewness of seasonal components.
                    summeddata_seasonal_ctmass_skewness.append(skew(temp_df, axis = 0, bias=True).tolist()) 
                    # Getting kurtosis of seasonal components.
                    summeddata_seasonal_ctmass_kurtosis.append(kurtosis(temp_df, axis = 0, bias=True).tolist())
                    namesofmyData_ctmass.append(filename[:-7])
    seasonal_process_ctmass_df = pd.DataFrame()
    seasonal_process_ctmass_df['Summed seasonal ctmass mean'] = summeddata_seasonal_ctmass_mean
    seasonal_process_ctmass_df['Summed seasonal ctmass median'] = summeddata_seasonal_ctmass_median
    seasonal_process_ctmass_df['Summed seasonal ctmass std'] = summeddata_seasonal_ctmass_std
    seasonal_process_ctmass_df['Summed seasonal ctmass skewness'] = summeddata_seasonal_ctmass_skewness
    seasonal_process_ctmass_df['Summed seasonal ctmass kurtosis'] = summeddata_seasonal_ctmass_kurtosis
    return seasonal_process_ctmass_df
        
def seasonal_process_aq(directory, myData_aq, namesofmyData_aq, originalNineteenWells):
    """ Processes seasonal components of original time-series to return mean,
    median, standard deviation, skewness, and kurtosis of all 19 wells.
   
    Parameters
    ----------
    directory : string
       directory in which seasonal aqueous rate components are located.
    myData_aq : list
       empty list that will contain the scaled seasonal aqueous rate
       components after function executes.
    namesofmyData_aq: list
       empty list that will contain the names of the 19 wells.
    originalNineteenWells: list
       list of 19 wells from the orginal time-series data joblib file. Used to 
       cross reference with name of well from the seasonal aqueous rate
       joblib file to ensure sure that the proper 19 wells' seasonal components
       are being processed.

    Returns
    -------
    seasonal_process_aq_df: Dataframe
       Contains mean, median, standard deviation, skewness, and kurtosis of all 
       19 wells' seasonal aqueous rate.
    """
    summeddata_seasonal_aq_mean = [] 
    summeddata_seasonal_aq_median = [] 
    summeddata_seasonal_aq_std = []
    summeddata_seasonal_aq_skewness = [] 
    summeddata_seasonal_aq_kurtosis = []
    for filename in os.listdir(directory):
        for well in range(0, len(originalNineteenWells)):
           if filename.endswith("CTAqMass.joblib"):
               if(filename.replace('-CTAqMass.joblib', '') == originalNineteenWells[well]):
                   temp_df = joblib.load(directory+filename)
                   temp_df = pd.DataFrame(temp_df.loc[:,temp_df.columns != 'F0'].sum(axis = 1), columns = ['Sum of Components'])
    
                   # Scaling summed seasonal aq vals between 0 and 1 here.
                   scaler = MinMaxScaler()               
                   temp_df = scaler.fit_transform(temp_df)
                   temp_df = pd.DataFrame(temp_df.flatten())
                   myData_aq.append(temp_df)
                   
                   # Getting the average of the seasonal components.
                   summeddata_seasonal_aq_mean.append(temp_df.mean(axis = 0).tolist())   
                   # Getting median of seasonal components.
                   summeddata_seasonal_aq_median.append(temp_df.median(axis = 0).tolist()) 
                   # Getting std of seasonal components.
                   summeddata_seasonal_aq_std.append(temp_df.std(axis = 0).tolist()) 
                   # Getting skewness of seasonal components.
                   summeddata_seasonal_aq_skewness.append(skew(temp_df, axis = 0, bias=True).tolist()) 
                   # Getting skewness of seasonal components.
                   summeddata_seasonal_aq_kurtosis.append(kurtosis(temp_df, axis = 0, bias=True).tolist()) 
                   namesofmyData_aq.append(filename[:-7])
    seasonal_process_aq_df = pd.DataFrame()
    seasonal_process_aq_df['Summed seasonal aq mean'] = summeddata_seasonal_aq_mean
    seasonal_process_aq_df['Summed seasonal aq median'] = summeddata_seasonal_aq_median
    seasonal_process_aq_df['Summed seasonal aq std'] = summeddata_seasonal_aq_std
    seasonal_process_aq_df['Summed seasonal aq skewness'] = summeddata_seasonal_aq_skewness
    seasonal_process_aq_df['Summed seasonal aq kurtosis'] = summeddata_seasonal_aq_kurtosis
    return seasonal_process_aq_df
   
# Trend component data processing.
def trend_process_conc(directory, myData, namesofmyData, originalNineteenWells):
    """ Processes trend components of original time-series to return mean,
    median, standard deviation, skewness, and kurtosis of all 19 wells.
   
    Parameters
    ----------
    directory : string
       directory in which trend CCL4 concentration components are located.
    myData : list
       empty list that will contain the scaled trend CCL4 concentration 
       components after function executes.
    namesofmyData: list
       empty list that will contain the names of the 19 wells.
    originalNineteenWells: list
       list of 19 wells from the orginal time-series data joblib file. Used to 
       cross reference with name of well from the trend CCL4 concentration 
       joblib file to ensure sure that the proper 19 wells' trend components
       are being processed.

    Returns
    -------
    trend_process_conc_df: Dataframe
       Contains mean, median, standard deviation, skewness, and kurtosis of all 
       19 wells' trend CCL4 concentration.
    """
    trend_conc_mean= [] 
    trend_conc_median = []
    trend_conc_std = []
    trend_conc_skewness = []
    trend_conc_kurtosis = []
    for filename in os.listdir(directory):
        for well in range(0, len(originalNineteenWells)):
            if filename.endswith("Concentration.joblib"):
                if(filename.replace('-Concentration.joblib', '') == originalNineteenWells[well]):
                    temp_df = joblib.load(directory+filename)
                    temp_df = temp_df.loc[:,["F0"]]
                    
                    # Scaling trend concentration vals between 0 and 1 here.
                    scaler = MinMaxScaler()               
                    temp_df = scaler.fit_transform(temp_df)
                    temp_df = pd.DataFrame(temp_df.flatten())
                    myData.append(temp_df)
                    
                    # Getting the average of the trend components.
                    trend_conc_mean.append(temp_df.mean(axis = 0).tolist())  
                    # Getting median of trend components.
                    trend_conc_median.append(temp_df.median(axis = 0).tolist()) 
                    # Getting std of trend components.
                    trend_conc_std.append(temp_df.std(axis = 0).tolist()) 
                    # Getting skewness of trend components.
                    trend_conc_skewness.append(skew(temp_df, axis = 0, bias=True).tolist()) 
                    # Getting kurtosis of trend components.
                    trend_conc_kurtosis.append(kurtosis(temp_df, axis = 0, bias=True).tolist()) 
                    namesofmyData.append(filename[:-7])
    trend_process_conc_df = pd.DataFrame()
    trend_process_conc_df['Trend conc mean'] = trend_conc_mean
    trend_process_conc_df['Trend conc median'] = trend_conc_median
    trend_process_conc_df['Trend conc std'] = trend_conc_std
    trend_process_conc_df['Trend conc skewness'] = trend_conc_skewness
    trend_process_conc_df['Trend conc kurtosis'] = trend_conc_kurtosis
    return trend_process_conc_df

def trend_process_ctmass(directory, myData_ctmass, namesofmyData_ctmass, originalNineteenWells):
    """ Processes trend components of original time-series to return mean,
    median, standard deviation, skewness, and kurtosis of all 19 wells.
   
    Parameters
    ----------
    directory : string
       directory in which trend CCL4 mass components are located.
    myData_ctmass : list
       empty list that will contain the scaled trend CCL4 mass. 
       components after function executes.
    namesofmyData_ctmass: list
       empty list that will contain the names of the 19 wells.
    originalNineteenWells: list
       list of 19 wells from the orginal time-series data joblib file. Used to 
       cross reference with name of well from the trend CCL4 mass
       joblib file to ensure sure that the proper 19 wells' trend components
       are being processed.

    Returns
    -------
    trend_process_ctmass_df: Dataframe
       Contains mean, median, standard deviation, skewness, and kurtosis of all 
       19 wells' trend CCL4 mass.
    """
    trend_ctmass_mean= [] 
    trend_ctmass_median = []
    trend_ctmass_std = []
    trend_ctmass_skewness = []
    trend_ctmass_kurtosis = []
    for filename in os.listdir(directory):
       for well in range(0, len(originalNineteenWells)):
           if filename.endswith("CTMass.joblib"):
               if(filename.replace('-CTMass.joblib', '') == originalNineteenWells[well]):
                   temp_df = joblib.load(directory+filename)
                   temp_df = temp_df.loc[:,["F0"]]
                   
                   # Scaling trend ctmass vals between 0 and 1 here.
                   scaler = MinMaxScaler()               
                   temp_df = scaler.fit_transform(temp_df)      
                   temp_df = pd.DataFrame(temp_df.flatten())
                   myData_ctmass.append(temp_df)
                   
                   # Getting the average of the trend components.
                   trend_ctmass_mean.append(temp_df.mean(axis = 0).tolist())  
                   # Getting median of trend components.
                   trend_ctmass_median.append(temp_df.median(axis = 0).tolist()) 
                   # Getting std of trend components.
                   trend_ctmass_std.append(temp_df.std(axis = 0).tolist()) 
                   # Getting skewness of trend components.
                   trend_ctmass_skewness.append(skew(temp_df, axis = 0, bias=True).tolist()) 
                   # Getting kurtosis of trend components.
                   trend_ctmass_kurtosis.append(kurtosis(temp_df, axis = 0, bias=True).tolist()) 
                   namesofmyData_ctmass.append(filename[:-7])
    trend_process_ctmass_df = pd.DataFrame()
    trend_process_ctmass_df['Trend ctmass mean'] = trend_ctmass_mean
    trend_process_ctmass_df['Trend ctmass median'] = trend_ctmass_median
    trend_process_ctmass_df['Trend ctmass std'] = trend_ctmass_std
    trend_process_ctmass_df['Trend ctmass skewness'] = trend_ctmass_skewness
    trend_process_ctmass_df['Trend ctmass kurtosis'] = trend_ctmass_kurtosis
    return trend_process_ctmass_df
        
def trend_process_aq(directory, myData_aq, namesofmyData_aq, originalNineteenWells):
    """ Processes trend components of original time-series to return mean,
    median, standard deviation, skewness, and kurtosis of all 19 wells.
   
    Parameters
    ----------
    directory : string
       directory in which trend aqueous rate components are located.
    myData_aq : list
       empty list that will contain the scaled trend aqueous rate
       components after function executes.
    namesofmyData_aq: list
       empty list that will contain the names of the 19 wells.
    originalNineteenWells: list
       list of 19 wells from the orginal time-series data joblib file. Used to 
       cross reference with name of well from the trend aqueous rate 
       joblib file to ensure sure that the proper 19 wells' trend components
       are being processed.

    Returns
    -------
    trend_process_conc_aq: Dataframe
       Contains mean, median, standard deviation, skewness, and kurtosis of all 
       19 wells' trend aqueous rate.
    """
    trend_aq_mean= [] 
    trend_aq_median = []
    trend_aq_std = []
    trend_aq_skewness = []
    trend_aq_kurtosis = []
    for filename in os.listdir(directory):
        for well in range(0, len(originalNineteenWells)):
            if filename.endswith("CTAqMass.joblib"):
                if(filename.replace('-CTAqMass.joblib', '') == originalNineteenWells[well]):
                    temp_df = joblib.load(directory+filename)
                    temp_df = temp_df.loc[:,["F0"]]
                    
                    # Scaling trend aq vals between 0 and 1 here.
                    scaler = MinMaxScaler()               
                    temp_df = scaler.fit_transform(temp_df)      
                    temp_df = pd.DataFrame(temp_df.flatten())
                    myData_aq.append(temp_df)
                    
                    # Getting the average of the trend components.
                    trend_aq_mean.append(temp_df.mean(axis = 0).tolist())     
                    # Getting median of trend components.
                    trend_aq_median.append(temp_df.median(axis = 0).tolist()) 
                    # Getting std of trend components.
                    trend_aq_std.append(temp_df.std(axis = 0).tolist()) 
                    # Getting std of trend components.
                    trend_aq_skewness.append(skew(temp_df, axis = 0, bias=True).tolist()) 
                    # Getting kurtosis of trend components.
                    trend_aq_kurtosis.append(kurtosis(temp_df, axis = 0, bias=True).tolist()) 
                    namesofmyData_aq.append(filename[:-7])
    trend_process_aq_df = pd.DataFrame()
    trend_process_aq_df['Trend aq mean'] = trend_aq_mean
    trend_process_aq_df['Trend aq median'] = trend_aq_median
    trend_process_aq_df['Trend aq std'] = trend_aq_std
    trend_process_aq_df['Trend aq skewness'] = trend_aq_skewness
    trend_process_aq_df['Trend aq kurtosis'] = trend_aq_kurtosis
    return trend_process_aq_df
        
# Noise component data processing
def noise_process_conc(directory, myData, namesofmyData, originalNineteenWells):
    """ Processes noise components of original time-series to return mean,
    median, standard deviation, skewness, and kurtosis of all 19 wells.
   
    Parameters
    ----------
    directory : string
       directory in which noise CCL4 concentration components are located.
    myData : list
       empty list that will contain the scaled noise CCL4 concentration 
       components after function executes.
    namesofmyData: list
       empty list that will contain the names of the 19 wells.
    originalNineteenWells: list
       list of 19 wells from the orginal time-series data joblib file. Used to 
       cross reference with name of well from the noise CCL4 concentration 
       joblib file to ensure sure that the proper 19 wells' noise components
       are being processed.

    Returns
    -------
    summed_noise_process_conc_df: Dataframe
       Contains mean, median, standard deviation, skewness, and kurtosis of all 
       19 wells' noise CCL4 concentration.
    """
    summeddata_noise_conc_mean = []
    summeddata_noise_conc_median = []
    summeddata_noise_conc_std = []
    summeddata_noise_conc_skewness = []
    summeddata_noise_conc_kurtosis = []
    for filename in os.listdir(directory):
        for well in range(0, len(originalNineteenWells)):
            if filename.endswith("Concentration-Noise.joblib"):
                if(filename.replace('-Concentration-Noise.joblib', '') == originalNineteenWells[well]):
                    temp_df = joblib.load(directory+filename)
                    temp_df = pd.DataFrame(temp_df.loc[:,temp_df.columns].sum(axis = 1), columns = ['Sum of Components'])
                    
                    # Scaling summed noise concentration vals between 0 and 1 here.
                    scaler = MinMaxScaler()               
                    temp_df = scaler.fit_transform(temp_df)
                    temp_df = pd.DataFrame(temp_df.flatten())
                    myData.append(temp_df)
                    
                    # Getting the average of the noise components.
                    summeddata_noise_conc_mean.append(temp_df.mean(axis = 0).tolist())  
                    # Getting median of noise components.
                    summeddata_noise_conc_median.append(temp_df.median(axis = 0).tolist()) 
                    # Getting std of noise components.
                    summeddata_noise_conc_std.append(temp_df.std(axis = 0).tolist()) 
                    # Getting skewness of noise components.
                    summeddata_noise_conc_skewness.append(skew(temp_df, axis = 0, bias=True).tolist()) 
                    # Getting kurtosis of noise components.
                    summeddata_noise_conc_kurtosis.append(kurtosis(temp_df, axis = 0, bias=True).tolist()) 
                    namesofmyData.append(filename[:-7])
    summed_noise_process_conc_df = pd.DataFrame()
    summed_noise_process_conc_df['Summed noise conc mean'] = summeddata_noise_conc_mean
    summed_noise_process_conc_df['Summed noise conc median'] = summeddata_noise_conc_median
    summed_noise_process_conc_df['Summed noise conc std'] = summeddata_noise_conc_std
    summed_noise_process_conc_df['Summed noise conc skewness'] = summeddata_noise_conc_skewness
    summed_noise_process_conc_df['Summed noise conc kurtosis'] = summeddata_noise_conc_kurtosis
    return summed_noise_process_conc_df

def noise_process_ctmass(directory, myData_ctmass, namesofmyData_ctmass, originalNineteenWells):
    """ Processes noise components of original time-series to return mean,
    median, standard deviation, skewness, and kurtosis of all 19 wells.
   
    Parameters
    ----------
    directory : string
       directory in which noise CCL4 mass components are located.
    myData_ctmass : list
       empty list that will contain the scaled noise CCL4 mass
       components after function executes.
    namesofmyData_ctmass: list
       empty list that will contain the names of the 19 wells.
    originalNineteenWells: list
       list of 19 wells from the orginal time-series data joblib file. Used to 
       cross reference with name of well from the noise CCL4 mass 
       joblib file to ensure sure that the proper 19 wells' noise components
       are being processed.

    Returns
    -------
    summed_noise_process_ctmass_df: Dataframe
       Contains mean, median, standard deviation, skewness, and kurtosis of all 
       19 wells' noise CCL4 mass.
    """
    summeddata_noise_ctmass_mean = []
    summeddata_noise_ctmass_median = []
    summeddata_noise_ctmass_std = []
    summeddata_noise_ctmass_skewness = []
    summeddata_noise_ctmass_kurtosis = []
    for filename in os.listdir(directory):
        for well in range(0, len(originalNineteenWells)):
           if filename.endswith("CTMass-Noise.joblib"):
               if(filename.replace('-CTMass-Noise.joblib', '') == originalNineteenWells[well]):
                   temp_df = joblib.load(directory+filename)
                   temp_df = pd.DataFrame(temp_df.loc[:,temp_df.columns].sum(axis = 1), columns = ['Sum of Components'])
                   
                   # Scaling summed noise ctmass vals between 0 and 1 here.
                   scaler = MinMaxScaler()               
                   temp_df = scaler.fit_transform(temp_df)      
                   temp_df = pd.DataFrame(temp_df.flatten())
                   myData_ctmass.append(temp_df)
                   
                   # Getting the average of the noise components.
                   summeddata_noise_ctmass_mean.append(temp_df.mean(axis = 0).tolist())  
                   # Getting median of noise components.
                   summeddata_noise_ctmass_median.append(temp_df.median(axis = 0).tolist()) 
                   # Getting std of noise components.
                   summeddata_noise_ctmass_std.append(temp_df.std(axis = 0).tolist()) 
                   # Getting skewness of noise components.
                   summeddata_noise_ctmass_skewness.append(skew(temp_df, axis = 0, bias=True).tolist()) 
                   # Getting kurtosis of noise components.
                   summeddata_noise_ctmass_kurtosis.append(kurtosis(temp_df, axis = 0, bias=True).tolist()) 
                   namesofmyData_ctmass.append(filename[:-7])
    summed_noise_process_ctmass_df = pd.DataFrame()
    summed_noise_process_ctmass_df['Summed noise ctmass mean'] = summeddata_noise_ctmass_mean
    summed_noise_process_ctmass_df['Summed noise ctmass median'] = summeddata_noise_ctmass_median
    summed_noise_process_ctmass_df['Summed noise ctmass std'] = summeddata_noise_ctmass_std
    summed_noise_process_ctmass_df['Summed noise ctmass skewness'] = summeddata_noise_ctmass_skewness
    summed_noise_process_ctmass_df['Summed noise ctmass kurtosis'] = summeddata_noise_ctmass_kurtosis
    return summed_noise_process_ctmass_df
        
def noise_process_aq(directory, myData_aq, namesofmyData_aq, originalNineteenWells):
    """ Processes noise components of original time-series to return mean,
    median, standard deviation, skewness, and kurtosis of all 19 wells.
   
    Parameters
    ----------
    directory : string
       directory in which noise aqueous rate components are located.
    myData_aq : list
       empty list that will contain the scaled noise aqueous rate
       components after function executes.
    namesofmyData_aq: list
       empty list that will contain the names of the 19 wells.
    originalNineteenWells: list
       list of 19 wells from the orginal time-series data joblib file. Used to 
       cross reference with name of well from the noise aqueous rate
       joblib file to ensure sure that the proper 19 wells' noise components
       are being processed.

    Returns
    -------
    summed_noise_process_aq_df: Dataframe
       Contains mean, median, standard deviation, skewness, and kurtosis of all 
       19 wells' noise aqueous rate.
    """
    summeddata_noise_aq_mean = []
    summeddata_noise_aq_median = []
    summeddata_noise_aq_std = []
    summeddata_noise_aq_skewness = []
    summeddata_noise_aq_kurtosis = []
    for filename in os.listdir(directory):
        for well in range(0, len(originalNineteenWells)):
            if filename.endswith("CTAqMass-Noise.joblib"):
                if(filename.replace('-CTAqMass-Noise.joblib', '') == originalNineteenWells[well]):
                    temp_df = joblib.load(directory+filename)
                    temp_df = pd.DataFrame(temp_df.loc[:,temp_df.columns].sum(axis = 1), columns = ['Sum of Components'])
                    
                    # Scaling summed noise aq vals between 0 and 1 here.
                    scaler = MinMaxScaler()               
                    temp_df = scaler.fit_transform(temp_df)      
                    temp_df = pd.DataFrame(temp_df.flatten())
                    myData_aq.append(temp_df)
                    
                    # Getting the average of the noise components.
                    summeddata_noise_aq_mean.append(temp_df.mean(axis = 0).tolist())     
                    # Getting median of noise components.
                    summeddata_noise_aq_median.append(temp_df.median(axis = 0).tolist()) 
                    # Getting std of noise components.
                    summeddata_noise_aq_std.append(temp_df.std(axis = 0).tolist()) 
                    # Getting skewness of noise components.
                    summeddata_noise_aq_skewness.append(skew(temp_df, axis = 0, bias=True).tolist()) 
                    # Getting kurtosis of noise components.
                    summeddata_noise_aq_kurtosis.append(kurtosis(temp_df, axis = 0, bias=True).tolist()) 
                    namesofmyData_aq.append(filename[:-7])
    summed_noise_process_aq_df = pd.DataFrame()
    summed_noise_process_aq_df['Summed noise aq mean'] = summeddata_noise_aq_mean
    summed_noise_process_aq_df['Summed noise aq median'] = summeddata_noise_aq_median
    summed_noise_process_aq_df['Summed noise aq std'] = summeddata_noise_aq_std
    summed_noise_process_aq_df['Summed noise aq skewness'] = summeddata_noise_aq_skewness
    summed_noise_process_aq_df['Summed noise aq kurtosis'] = summeddata_noise_aq_kurtosis
    return summed_noise_process_aq_df
        


# Performing statistical operations on scaled data and a master df is returned.
def create_df(originalNineteenWells, scaled_vals_conc_df, scaled_vals_ctmass_df, scaled_vals_aq_df): 
    """ Obtaining mean, min, max, 25th percentile, 50th percentile, 75th
        percentile, and standard deviation of original time-series values for
        CCL4 concentration, mass, and aqueous rate.
   
    Parameters
    ----------
    originalNineteenWells: list
       list of 19 wells from the orginal time-series data joblib file. 
    scaled_vals_conc_df : Dataframe
       contains scaled CCL4 concentration data across all wells.
    scaled_vals_ctmass_df : Dataframe
       contains scaled CCL4 mass data across all wells.
    scaled_vals_aq_df : Dataframe
       contains scaled CCL4 aqueous rate across all wells.

    Returns
    -------
    df: Dataframe
       Contains mean, min, max, 25th percentile, 50th percentile, 75th
       percentile, and standard deviation of original time-series values for
       scaled CCL4 concentration, mass, and aqueous rate for all 19 wells. Also
       contains the number of months each well was active.
    """
    # List of all 19 well names
    well_name = []
    # Total (average) concentration values for 19 wells over 8 year period.
    conc_total = [] 
    # Total carbon tet mass values for 19 wells over 8 year period.
    ct_mass_total = []
    # Total aqueous rate values for 19 wells over 8 year period.
    aqueous_total = [] 
    # Maximum concentration values for 19 wells.
    max_conc = [] 
    # Minimum concentration values for 19 wells.
    min_conc = []
    # Maximum ct mass values for 19 wells.
    max_ct_mass = [] 
    # Minimum min ct mass values for 19 wells.
    min_ct_mass = []
    # Maximum aqueous rate values for 19 wells.
    max_aqueous = []
    # Minimum aqueous rate values for 19 wells.
    min_aqueous = [] 
    # 25th percentile for concentration, ct mass, and aqueous rate for 19 wells.
    twenty_fifth_pc_conc = []  
    twenty_fifth_pc_ctmass = []
    twenty_fifth_pc_aqueous = []
    # 50th percentile for concentration, ct mass, and aqueous rate for 19 wells.
    fifty_pc_conc= []          
    fifty_pc_ctmass = []
    fifty_pc_aqueous = []
    # 75th percentile for concentration, ct mass, and aqueous rate for 19 wells.
    seventy_fifth_pc_conc = []   
    seventy_fifth_pc_ctmass = []
    seventy_fifth_pc_aqueous = []
    # STD for conc, ctmass, and aq mass for 19 wells.
    std_conc = []           
    std_ct_mass = []
    std_aqueous = []
    num_months_inactive_ctmass = []
    num_months_inactive_aqueous = []
    for i in range(0, len(originalNineteenWells)):
        well_name.append(originalNineteenWells[i])
        temp_conc = scaled_vals_conc_df.iloc[:, i]
        temp_ctmass = scaled_vals_ctmass_df.iloc[:, i]
        temp_aqueous = scaled_vals_aq_df.iloc[:, i]
       
        conc_total.append(temp_conc.mean())       
        ct_mass_total.append(temp_ctmass.mean())  
        aqueous_total.append(temp_aqueous.mean()) 
        max_conc.append(temp_conc.max())          
        # Finding min value that is nonzero.
        min_conc.append(temp_conc[temp_conc != 0].min())          
        max_ct_mass.append(temp_ctmass.max())               
        # Finding min value that is nonzero.
        min_ct_mass.append(temp_ctmass[temp_ctmass != 0].min())    
        max_aqueous.append(temp_aqueous.max())
        # Finding min value that is nonzero.
        min_aqueous.append(temp_aqueous[temp_aqueous != 0].min())  
        twenty_fifth_pc_conc.append(temp_conc.quantile(.25))
        twenty_fifth_pc_ctmass.append(temp_ctmass.quantile(.25))
        twenty_fifth_pc_aqueous.append(temp_aqueous.quantile(.25))
        fifty_pc_conc.append(temp_conc.quantile(.50))
        fifty_pc_ctmass.append(temp_ctmass.quantile(.50))
        fifty_pc_aqueous.append(temp_aqueous.quantile(.50))
        seventy_fifth_pc_conc.append(temp_conc.quantile(.75))
        seventy_fifth_pc_ctmass.append(temp_ctmass.quantile(.75))
        seventy_fifth_pc_aqueous.append(temp_aqueous.quantile(.75))
        std_conc.append(temp_conc.std())
        std_ct_mass.append(temp_ctmass.std())
        std_aqueous.append(temp_aqueous.std())
    
        # Loop to check number of months well was inactive based on aqueous rate
        # and ct mass data.
        counter = 0
        for  i in range(0, len(temp_conc)):
            if(temp_ctmass[i] == 0):
                counter += 1 
        num_months_inactive_ctmass.append(counter)
    
        new_counter = 0
        for  i in range(0, len(temp_conc)):
            if(temp_aqueous[i] == 0):
                new_counter += 1 
        num_months_inactive_aqueous.append(counter)
        
    months_active = []
    for i in range(0, len(num_months_inactive_ctmass)):
        months_active.append(len(temp_conc) - num_months_inactive_ctmass[i])

    # Creating master df for all stats for mass recovery time series data.    
    df = pd.DataFrame(list(zip(well_name, conc_total, ct_mass_total, aqueous_total, 
                   max_conc, min_conc, max_ct_mass, min_ct_mass, 
                   max_aqueous, min_aqueous, twenty_fifth_pc_conc, 
                   twenty_fifth_pc_ctmass, twenty_fifth_pc_aqueous, 
                   fifty_pc_conc, fifty_pc_ctmass, fifty_pc_aqueous, 
                   seventy_fifth_pc_conc, seventy_fifth_pc_ctmass,
                   seventy_fifth_pc_aqueous, std_conc, std_ct_mass, 
                   std_aqueous, months_active)), 
                   columns = ['Well Names', 'Total Concentration', 'Total CT Mass',
                              'Total Aqueous', 'Max Concentration', 'Min Concentration',
                              'Max CT mass', 'Min CT mass', 'Max Aqueous', 'Min Aqueous', 
                              '25th Percentile Concentration', '25th Percentile CT mass',
                              '25th Percentile Aqueous', '50th Percentile Concentration',
                              '50th Percentile CT mass', '50th Percentile Aqueous',
                              '75th Percentile Concentration', '75th Percentile CT mass',
                              '75th Percentile Aqueous', 'STD Conc', 'STD CT mass',
                              'STD Aqueous', 'Number of months wells have been active'])
    return df

#%%
# Plots filled contour plot (2D at certain elevation point).
def generate_2D_contours(X_ax, Y_ax, orig_data_plume_array, namesofmyData, well_name):
    """ Taking geostatistical visulizations and plotting the CCL4 concentration
    values in a 2-D countour plot with the 19 wells' locations overlayed on 
    top.
   
    Parameters
    ----------
    X_ax: numpy array
       domain of 125 X values for the grid ranging from 565300 to 571550 with 
       grid intervals of 50.
    Y_ax : numpy array
       range of 115 Y values for the grid ranging from 133000 to 138750 with 
       grid intervals of 50.
    orig_data_plume_array : 3-D numpy array
       contains geostatistical visulization CCL4 concentration data.
    namesofmyData : list
       contains names of the 19 wells we are analyzing.
    well_name : list
       contains names of the 19 wells we are analyzing from the original time-
       series data joblib file. Used for cross-referencing later with 
       namesofmyData.
    """
    for i in range(0, orig_data_plume_array.shape[2]):
        fig, ax = plt.subplots(1, 1) 
        plt.figure(figsize = (50, 50))
        cax = ax.contourf(X_ax, Y_ax, orig_data_plume_array[:,:,i].T, cmap = 'plasma')
        ax.set_title('Contour Plot at elevation ' + str(Z_ax[i]) + ' meters') 
        ax.set_xlabel('Easting (m)') 
        ax.set_ylabel('Northing (m)') 
        ax.set_xlim(566000, 568700)
        ax.set_ylim(135250, 137700)
        cb = fig.colorbar(cax, orientation = 'vertical', pad = 0.1)
        cb.set_label('CCL4 Concentration (ug/L)')
    
        # Getting X, Y. and Z locations of wells in our selected wells dataset. 
        X = [];
        Y = [];
        Z = [];
        for i in range(0,len(namesofmyData)):
            for j in range(0,len(well_name)):
                if namesofmyData[i].replace('-Concentration-Noise', '') == well_name[j]:
                    X.append(data.get('x')[j])
                    Y.append(data.get('y')[j])
                    Z.append((data.get('top')[j] + data.get('bottom')[j]) / 2)
        ax.plot(X, Y, 'o')
        for i,txt in enumerate(namesofmyData):
            ax.annotate(namesofmyData[i].replace('-Concentration-Noise', ''), xy = (X[i], Y[i]), color = 'black')
        plt.show() 

# 3-D contour plot (At a given elevation). 
def generate_3D_contours(X_ax, Y_ax, orig_data_plume_array): 
    """ Taking geostatistical visulizations and plotting the CCL4 concentration
    values in a 3-D countour plot.
   
    Parameters
    ----------
    X_ax: numpy array
       domain of 125 X values for the grid ranging from 565300 to 571550 with 
       grid intervals of 50.
    Y_ax : numpy array
       range of 115 Y values for the grid ranging from 133000 to 138750 with 
       grid intervals of 50.
    orig_data_plume_array : 3-D numpy array
       contains geostatistical visulization CCL4 concentration data.
    """
    for q in range(0, orig_data_plume_array.shape[2]):
        fig = plt.figure(figsize = (9, 9))
        ax_two = plt.axes(projection='3d')
        cax_two = ax_two.contour3D(X_ax, Y_ax, orig_data_plume_array[:,:,q].T, cmap=cm.plasma)
        ax_two.set_title('Contour Plot at elevation ' + str(Z_ax[q]) + ' meters') 
        ax_two.set_xlabel('Easting (m)') 
        ax_two.set_ylabel('Northing (m)') 
        ax_two.set_zlabel('CCL4 Concentration (ug/L)')
        ax_two.set_box_aspect(aspect=None, zoom=0.9)
        ax_two.xaxis.labelpad = 20  # These adjust the postion of the labels down.
        ax_two.yaxis.labelpad = 10
    plt.show()

    
#%%    
# Computing euclidean distances (X, Y, and Z) from each point in plume to each of the 19 wells at all elevations.
def compute_eucid_dist(X_ax, Y_ax, Z_ax, X, Y, Z):
    """ Computing euclidean distance from each point in plume to each of the 
    19 wells at all elevations.
   
    Parameters
    ----------
    X_ax: numpy array
       domain of 125 X values for the grid ranging from 565300 to 571550 with 
       grid intervals of 50.
    Y_ax : numpy array
       range of 115 Y values for the grid ranging from 133000 to 138750 with 
       grid intervals of 50.
    Z_ax : numpy array
       depth / elevation of 26 Z values for the grid ranging from 7.5 to 132.5 
       with grid intervals of 5.
    X : list
       X coordinates (easting) of the 19 wells.
    Y : list 
       Y coordinates (northing) of the 19 wells.
    Z : list
       Z coordinates (depth / elevation) of the 19 wells.
    
    Returns
    -------
    dist: list
       Contains euclidean distance from each point in plume to each of the 
       19 wells at all elevations.
    """
    dist = []
    for well in range(0, len(X)):
        for point in range(0, len(X_ax)):
            for pointtwo in range(0, len(Y_ax)):
                for pointthree in range(0, len(Z_ax)):
                    dist.append(math.dist([X_ax[point], Y_ax[pointtwo], Z_ax[pointthree]], [X[well], Y[well], Z[well]]))
    return dist

# Computing concentration-weighted distance at all elevation points.   
def compute_inverse_weighted_dist(conc_weighted_dist, update_conc_dist, dist, X_ax, Y_ax, Z_ax, X, Y, Z):
    """ Computing concentration inverse weighted distance at all elevation 
    points.
   
    Parameters
    ----------
    conc_weighted_dist: list
       empty list that will contain the CCL4 concentration values for all 
       points in the plume after function executes.
    update_conc_dist: list
       list that will contain the concentration inverse weighted distance
       values after function execution.
    dist: list
       Contains euclidean distance from each point in plume to each of the 
       19 wells at all elevations.
    X_ax: numpy array
       domain of 125 X values for the grid ranging from 565300 to 571550 with 
       grid intervals of 50.
    Y_ax : numpy array
       range of 115 Y values for the grid ranging from 133000 to 138750 with 
       grid intervals of 50.
    Z_ax : numpy array
       depth / elevation of 26 Z values for the grid ranging from 7.5 to 132.5 
       with grid intervals of 5.
    X : list
       X coordinates (easting) of the 19 wells.
    Y : list 
       Y coordinates (northing) of the 19 wells.
    Z : list
       Z coordinates (depth / elevation) of the 19 wells.
    
    Returns
    -------
    update_conc_dist: list
       List that will contain the concentration inverse weighted distance
       values after function executes.
    """
    conc_weighted_dist = []
    for well in range(0, len(X)):
        for point in range(0, len(X_ax)):
            for pointtwo in range(0, len(Y_ax)):
                for pointthree in range(0, len(Z_ax)):
                    conc_weighted_dist.append(orig_data_plume_array[point][pointtwo][pointthree])
    # Formula is (1 / distance) * concentration at plume point.
    update_conc_dist = []
    for i in range(0, len(dist)):
        update_conc_dist.append((1 / dist[i]) * conc_weighted_dist[i])
    return update_conc_dist
       
#%% 
# Finding distance between plume points and specific well points between specified radius.
# Then computing the total mass (sum of concentration) for each well.
def total_mass_contamination_within_radius(total_concentration_from_plume,
                                           radius, X, X_ax, Y_ax, Z_ax, 
                                           orig_data_plume_array):
    """ Computing total CCL4 mass (sum of concentration) within a certain 
    radius for each of the 19 wells.
   
    Parameters
    ----------
    total_concentration_from_plume: list
       empty list that will contain the total CCL4 mass (sum of concentration)
       after function executes.
    radius: int
       Controls distance to search within.
    X : list
       X coordinates (easting) of the 19 wells.
    X_ax: numpy array
       domain of 125 X values for the grid ranging from 565300 to 571550 with 
       grid intervals of 50.
    Y_ax : numpy array
       range of 115 Y values for the grid ranging from 133000 to 138750 with 
       grid intervals of 50.
    Z_ax : numpy array
       depth / elevation of 26 Z values for the grid ranging from 7.5 to 132.5 
       with grid intervals of 5.
    orig_data_plume_array : 3-D numpy array
       contains geostatistical visulization CCL4 concentration data.   
    
    Returns
    -------
    total_concentration_from_plume: list
       List that will contain the total CCL4 mass (sum of concentration)
       after function executes.
    """
    closest_points_in_radius_distance = []
    indices_from_orig_x = []
    indices_from_orig_y = []
    indices_from_orig_z = []
    total_concentration_from_plume = []
    point_concentration_value = 0
    breaks = []
    rad = radius
    counter = 0
    for well in range(0, len(X)):
        point_concentration_value = 0
        for point in range(0, len(X_ax)):
            for pointtwo in range(0, len(Y_ax)):
                for pointthree in range(0, len(Z_ax)):
                    if(math.dist([X_ax[point], Y_ax[pointtwo], Z_ax[pointthree]], [X[well], Y[well], Z[well]]) < rad):
                        closest_points_in_radius_distance.append(math.dist([X_ax[point], Y_ax[pointtwo], Z_ax[pointthree]], [X[well], Y[well], Z[well]]))
                        indices_from_orig_x.append(point)
                        indices_from_orig_y.append(pointtwo)
                        indices_from_orig_z.append(pointthree)
                        point_concentration_value += orig_data_plume_array[point][pointtwo][pointthree]
                        counter += 1
        total_concentration_from_plume.append(point_concentration_value)
        breaks.append(counter)
        
    return total_concentration_from_plume

# This function plots the closest points in 3D to a a certain number of wells.
# Number of wells represented by well_num.
def plot_closest_points(X, Y, Z, contour_points_x, contour_points_y, contour_points_z, 
                        well_num, radius):
    """ Computing total CCL4 mass (sum of concentration) within a certain 
    radius for each of the 19 wells.
   
    Parameters
    ----------
    X : list
       X coordinates (easting) of the 19 wells.
    Y : list 
       Y coordinates (northing) of the 19 wells.
    Z : list
       Z coordinates (depth / elevation) of the 19 wells.
    contour_points_x : list 
       contains all possible x coordinates along the grid.
    contour_points_y : list
       contains all possible y coordinates along the grid.
    contour_points_z : list 
       contains all possible z coordinates along the grid.
    well_num : int
       controls which of the 19 wells to plot the closest points for. 
       ranges from (0-18).
    radius: int
        controls distance to search within.
    """  
    # Another way to find closest distance within certain radius (meters) and 
    # plotting 3d scatter points here for a well and the points closest to it
    # within a certain radius (meters).
    x, y, z = np.array([contour_points_x, contour_points_y, contour_points_z])
    points = np.c_[x.ravel(), y.ravel(), z.ravel()]
    tree = spatial.KDTree(points)
    
    fig = plt.figure(figsize = (9, 9))
    ax_four = plt.axes(projection='3d')
    for i in range(0, well_num):
        ax_four.scatter3D(X[i], Y[i], Z[i], color = 'black', alpha = 1)
    ax_four.set_title('3D scatterplot of ' + str(well_num) +  ' wells and their closest points within ' + str(radius) + ' meters.') 
    ax_four.set_xlabel('Easting (m)') 
    ax_four.set_ylabel('Northing (m)') 
    ax_four.set_zlabel('Elevation')
    ax_four.view_init(60, 35)
    ax_four.set_box_aspect(aspect=None, zoom=0.9)
    ax_four.xaxis.labelpad = 20  # These adjust the postion of the labels down.
    ax_four.yaxis.labelpad = 10
    
    rad = radius
    near_p = []
    for i in range(0, well_num):
        for results in tree.query_ball_point([X[i], Y[i], Z[i]], rad):
            nearby_points = points[results]   
            near_p.append(nearby_points)
        for i in range(0, len(near_p)):
            ax_four.scatter3D(near_p[i][0], near_p[i][1], near_p[i][2], color = 'green')
            
    black_patch = mpatches.Patch(color='black', label='Well coordinates')
    green_patch = mpatches.Patch(color='green', label='Closest points')

    plt.legend(handles=[black_patch, green_patch])
    plt.show()    

#%%
# Driver code / main code.

# Loading directories and joblib files.
directory = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/'
original_time_series = joblib.load('/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/Rohan_data/Week1/well_ts.joblib')
data = joblib.load('/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/Rohan_data/Week1/well_info.joblib')
originalNineteenWells = joblib.load('/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/well_names.joblib')
keys_list = list(original_time_series.keys())
for i,txt in enumerate(originalNineteenWells):
    originalNineteenWells[i] = originalNineteenWells[i].replace('-Concentration', '')
    
# Gathering summed seasonal component statistics.
# Summed seasonal conc stats.
myData = []
namesofmyData = []
summed_seasonal_conc_df = pd.DataFrame()
summed_seasonal_conc_df = seasonal_process_conc(directory, myData, namesofmyData,
                                                originalNineteenWells)
# Summed seasonal ctmass stats.
myData_ctmass = []
namesofmyData_ctmass = []
summed_seasonal_ctmass_df = pd.DataFrame()
summed_seasonal_ctmass_df = seasonal_process_ctmass(directory, myData_ctmass, 
                                                    namesofmyData_ctmass,
                                                    originalNineteenWells)
# Summed seasonal aq rate stats.
myData_aq = []
namesofmyData_aq = []
summed_seasonal_aq_df = pd.DataFrame()
summed_seasonal_aq_df = seasonal_process_aq(directory, myData_aq, 
                                            namesofmyData_aq,
                                            originalNineteenWells)
# Gathering temporal component statistics
# Trend conc stats.
myData = []
namesofmyData = []
trend_conc_df = pd.DataFrame()
trend_conc_df = trend_process_conc(directory, myData, namesofmyData, 
                                   originalNineteenWells)
# Trend ctmass stats.
myData_ctmass = []
namesofmyData_ctmass = []
trend_ctmass_df = pd.DataFrame()
trend_ctmass_df = trend_process_ctmass(directory, myData_ctmass, 
                                       namesofmyData_ctmass, 
                                       originalNineteenWells) 
# Trend aq stats.
myData_aq = []
namesofmyData_aq = []
trend_aq_df = pd.DataFrame()
trend_aq_df = trend_process_aq(directory, myData_aq, namesofmyData_aq, 
                               originalNineteenWells)

# Gathering summed noise component statistics.
# Summed noise conc stats.
myData = []
namesofmyData = []
summed_noise_conc_df = pd.DataFrame()
summed_noise_conc_df = noise_process_conc(directory, myData, namesofmyData, 
                                          originalNineteenWells)

# Summed noise ctmass stats.
myData_ctmass = []
namesofmyData_ctmass = []
summed_noise_ctmass_df = pd.DataFrame()
summed_noise_ctmass_df = noise_process_ctmass(directory, myData_ctmass, 
                                              namesofmyData_ctmass, 
                                              originalNineteenWells)
# Summed noise aq stats.
myData_aq = []
namesofmyData_aq = []
summed_noise_aq_df = pd.DataFrame()
summed_noise_aq_df = noise_process_aq(directory, myData_aq, namesofmyData_aq, 
                                                    originalNineteenWells)

#%%
# Getting all of the temporal aspects of the mass recovery time series here.
well_name = []
master_df = pd.DataFrame()
 
# Scaling well concentration data across all wells (row-wise operation).
conc_df = pd.DataFrame()
for i in range(0, len(originalNineteenWells)):
    well_name.append(originalNineteenWells[i])
    temp_conc = original_time_series.get(originalNineteenWells[i]).get('ctet_conc')
    conc_df[originalNineteenWells[i]] = temp_conc

vals = conc_df.values.reshape(-1,1)
scaler = MinMaxScaler()               
scaled_vals_conc = scaler.fit_transform(vals)      # Scaling concentration vals between 0 and 1 here.
reshaped_scaled_vals_conc = scaled_vals_conc.reshape(conc_df.shape[0], len(originalNineteenWells))
scaled_vals_conc_df = pd.DataFrame(reshaped_scaled_vals_conc, index=conc_df.index, columns=conc_df.columns) 

# Scaling well ct mass data across all wells (row-wise operation).
tempo_df_ctmass = pd.DataFrame()
for i in range(0, len(originalNineteenWells)):
    well_name.append(originalNineteenWells[i])
    temp_ctmass = original_time_series.get(originalNineteenWells[i]).get('ctet_mass')
    tempo_df_ctmass[originalNineteenWells[i]] = temp_ctmass

vals = tempo_df_ctmass.values.reshape(-1,1)
scaler = MinMaxScaler()
scaled_vals_ctmass = scaler.fit_transform(vals)
reshaped_scaled_vals_ctmass = scaled_vals_ctmass.reshape(tempo_df_ctmass.shape[0], len(originalNineteenWells))
scaled_vals_ctmass_df = pd.DataFrame(reshaped_scaled_vals_ctmass, index=tempo_df_ctmass.index, columns=tempo_df_ctmass.columns)

# Scaling aq rate data across all wells (row-wise operation).
tempo_df_aq = pd.DataFrame()
for i in range(0, len(originalNineteenWells)):
    well_name.append(originalNineteenWells[i])
    temp_aqueous = original_time_series.get(originalNineteenWells[i]).get('aqueous')
    if(temp_aqueous.isnull().values.any()):                 # If value in well is NA, linearly interpolate that value.
        temp_aqueous.interpolate(method="linear", inplace = True)
    temp_aqueous = temp_aqueous.abs()
    tempo_df_aq[originalNineteenWells[i]] = temp_aqueous

vals = tempo_df_aq.values.reshape(-1,1)
scaler = MinMaxScaler()
scaled_vals_aq = scaler.fit_transform(vals)
reshaped_scaled_vals_aq = scaled_vals_aq.reshape(tempo_df_aq.shape[0], len(originalNineteenWells))
scaled_vals_aq_df = pd.DataFrame(reshaped_scaled_vals_aq, index=tempo_df_aq.index, columns=tempo_df_aq.columns)

# Creating master dataframe 
master_df = create_df(originalNineteenWells, scaled_vals_conc_df, scaled_vals_ctmass_df, scaled_vals_aq_df) 

#%%
# New plume realization data.
# Getting first 373750 values (1st realization), then reshaping it to be a
# 3-d array.
new_directory = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/2023_InternshipData/sspa_sgsim_backtr-out_2021-09-22_1835' 
myfile = open(new_directory + '/sgsim_backtr.txt', "r")

# Getting total number of lines in file.
num_lines = 0
for line in myfile:
    num_lines += 1
myfile.close() 

# Getting evenly spaced file line breaks at 373,750 to then reshape values
# in fortran order into a (125, 115, 26) array.
file_breaks = []
for i in range(0, num_lines + 1):
    if i != 0 and i % 373750 == 0:
         file_breaks.append(i)       

# Getting X, Y and Z locations of all the wells.
X = data.get("x")    
Y = data.get("y")    
well_name = data.get("well")
top = data.get("top")
bottom = data.get("bottom")
    
# Creating domain, range, and elevation points for concentration plumes.
X_ax = np.arange(565300, 571550, 50) # 125 X values
Y_ax = np.arange(133000, 138750, 50) # 115 Y values
Z_ax = np.arange(7.5, 137.5, 5)      # 26 Z values

# Adding all coordinates (X,Y, and Z) in contour plot to a list.
contour_points_x = []
contour_points_y = []
contour_points_z = []
for point in range(0, len(X_ax)):
    for pointtwo in range(0, len(Y_ax)):
        for pointthree in range(0, len(Z_ax)):
            contour_points_x.append(X_ax[point])
            contour_points_y.append(Y_ax[pointtwo])
            contour_points_z.append(Z_ax[pointthree])
            
# Appending temporal trend, seasonality, and noise components to master df.
# Summed seasonality components here.
summed_seasonal_conc_mean_list = []
summed_seasonal_conc_median_list = []
summed_seasonal_conc_std_list = []
summed_seasonal_conc_skewness_list = []
summed_seasonal_conc_kurtosis_list = []
for i in range(0, len(summed_seasonal_conc_df)):
    summed_seasonal_conc_mean_list.append(summed_seasonal_conc_df['Summed seasonal conc mean'][i][0])
    summed_seasonal_conc_median_list.append(summed_seasonal_conc_df['Summed seasonal conc median'][i][0])
    summed_seasonal_conc_std_list.append(summed_seasonal_conc_df['Summed seasonal conc std'][i][0])
    summed_seasonal_conc_skewness_list.append(summed_seasonal_conc_df['Summed seasonal conc skewness'][i][0])
    summed_seasonal_conc_kurtosis_list.append(summed_seasonal_conc_df['Summed seasonal conc kurtosis'][i][0])
master_df['Summmed seasonal concentration mean'] = summed_seasonal_conc_mean_list
master_df['Summmed seasonal concentration median'] = summed_seasonal_conc_median_list
master_df['Summmed seasonal concentration std'] = summed_seasonal_conc_std_list
master_df['Summmed seasonal concentration skewness'] = summed_seasonal_conc_skewness_list
scaler = MinMaxScaler()               
temp_skew = scaler.fit_transform(np.array(master_df['Summmed seasonal concentration skewness']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_skew = pd.DataFrame(temp_skew.flatten())
master_df['Summmed seasonal concentration skewness'] = temp_skew
master_df['Summmed seasonal concentration kurtosis'] = summed_seasonal_conc_kurtosis_list   
scaler = MinMaxScaler()               
temp_kurtosis = scaler.fit_transform(np.array(master_df['Summmed seasonal concentration kurtosis']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_kurtosis = pd.DataFrame(temp_kurtosis.flatten())
master_df['Summmed seasonal concentration kurtosis'] = temp_kurtosis
 
summed_seasonal_ctmass_mean_list = []
summed_seasonal_ctmass_median_list = []
summed_seasonal_ctmass_std_list = []
summed_seasonal_ctmass_skewness_list = []
summed_seasonal_ctmass_kurtosis_list = []
for i in range(0, len(summed_seasonal_ctmass_df)):
    summed_seasonal_ctmass_mean_list.append(summed_seasonal_ctmass_df['Summed seasonal ctmass mean'][i][0])
    summed_seasonal_ctmass_median_list.append(summed_seasonal_ctmass_df['Summed seasonal ctmass median'][i][0])
    summed_seasonal_ctmass_std_list.append(summed_seasonal_ctmass_df['Summed seasonal ctmass std'][i][0])
    summed_seasonal_ctmass_skewness_list.append(summed_seasonal_ctmass_df['Summed seasonal ctmass skewness'][i][0])
    summed_seasonal_ctmass_kurtosis_list.append(summed_seasonal_ctmass_df['Summed seasonal ctmass kurtosis'][i][0])
master_df['Summmed seasonal ctmass mean'] = summed_seasonal_ctmass_mean_list
master_df['Summmed seasonal ctmass median'] = summed_seasonal_ctmass_median_list
master_df['Summmed seasonal ctmass std'] = summed_seasonal_ctmass_std_list
master_df['Summmed seasonal ctmass skewness'] = summed_seasonal_ctmass_skewness_list
scaler = MinMaxScaler()               
temp_skew = scaler.fit_transform(np.array(master_df['Summmed seasonal ctmass skewness']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_skew = pd.DataFrame(temp_skew.flatten())
master_df['Summmed seasonal ctmass skewness'] = temp_skew
master_df['Summmed seasonal ctmass kurtosis'] = summed_seasonal_ctmass_kurtosis_list
scaler = MinMaxScaler()               
temp_kurtosis = scaler.fit_transform(np.array(master_df['Summmed seasonal ctmass kurtosis']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_kurtosis = pd.DataFrame(temp_kurtosis.flatten())
master_df['Summmed seasonal ctmass kurtosis'] = temp_kurtosis   

summed_seasonal_aq_mean_list = []
summed_seasonal_aq_median_list = []
summed_seasonal_aq_std_list = []
summed_seasonal_aq_skewness_list = []
summed_seasonal_aq_kurtosis_list = []
for i in range(0, len(summed_seasonal_aq_df)):
    summed_seasonal_aq_mean_list.append(summed_seasonal_aq_df['Summed seasonal aq mean'][i][0])
    summed_seasonal_aq_median_list.append(summed_seasonal_aq_df['Summed seasonal aq median'][i][0])
    summed_seasonal_aq_std_list.append(summed_seasonal_aq_df['Summed seasonal aq std'][i][0])
    summed_seasonal_aq_skewness_list.append(summed_seasonal_aq_df['Summed seasonal aq skewness'][i][0])
    summed_seasonal_aq_kurtosis_list.append(summed_seasonal_aq_df['Summed seasonal aq kurtosis'][i][0])
master_df['Summmed seasonal aq mean'] = summed_seasonal_aq_mean_list
master_df['Summmed seasonal aq median'] = summed_seasonal_aq_median_list
master_df['Summmed seasonal aq std'] = summed_seasonal_aq_std_list
master_df['Summmed seasonal aq skewness'] = summed_seasonal_aq_skewness_list 
scaler = MinMaxScaler()               
temp_skew = scaler.fit_transform(np.array(master_df['Summmed seasonal aq skewness']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_skew = pd.DataFrame(temp_skew.flatten())
master_df['Summmed seasonal aq skewness'] = temp_skew
master_df['Summmed seasonal aq kurtosis'] = summed_seasonal_aq_kurtosis_list 
scaler = MinMaxScaler()               
temp_kurtosis = scaler.fit_transform(np.array(master_df['Summmed seasonal aq kurtosis']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_kurtosis = pd.DataFrame(temp_kurtosis.flatten())
master_df['Summmed seasonal aq kurtosis'] = temp_kurtosis 

# Trend components here.
trend_conc_mean_list = []
trend_conc_median_list = []
trend_conc_std_list = []
trend_conc_skewness_list = []
trend_conc_kurtosis_list = []
for i in range(0, len(trend_conc_df)):
    trend_conc_mean_list.append(trend_conc_df['Trend conc mean'][i][0])
    trend_conc_median_list.append(trend_conc_df['Trend conc median'][i][0])
    trend_conc_std_list.append(trend_conc_df['Trend conc std'][i][0])
    trend_conc_skewness_list.append(trend_conc_df['Trend conc skewness'][i][0])
    trend_conc_kurtosis_list.append(trend_conc_df['Trend conc kurtosis'][i][0])
master_df['Trend concentration mean'] = trend_conc_mean_list
master_df['Trend concentration median'] = trend_conc_median_list
master_df['Trend concentration std'] = trend_conc_std_list
master_df['Trend concentration skewness'] = trend_conc_skewness_list
scaler = MinMaxScaler()               
temp_skew = scaler.fit_transform(np.array(master_df['Trend concentration skewness']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_skew = pd.DataFrame(temp_skew.flatten())
master_df['Trend concentration skewness'] = temp_skew
master_df['Trend concentration kurtosis'] = trend_conc_kurtosis_list
scaler = MinMaxScaler()               
temp_kurtosis = scaler.fit_transform(np.array(master_df['Trend concentration kurtosis']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_kurtosis = pd.DataFrame(temp_kurtosis.flatten())
master_df['Trend concentration kurtosis'] = temp_kurtosis

trend_ctmass_mean_list = []
trend_ctmass_median_list = []
trend_ctmass_std_list = []
trend_ctmass_skewness_list = []
trend_ctmass_kurtosis_list = []
for i in range(0, len(trend_ctmass_df)):
    trend_ctmass_mean_list.append(trend_ctmass_df['Trend ctmass mean'][i][0])
    trend_ctmass_median_list.append(trend_ctmass_df['Trend ctmass median'][i][0])
    trend_ctmass_std_list.append(trend_ctmass_df['Trend ctmass std'][i][0])
    trend_ctmass_skewness_list.append(trend_ctmass_df['Trend ctmass skewness'][i][0])
    trend_ctmass_kurtosis_list.append(trend_ctmass_df['Trend ctmass kurtosis'][i][0])
master_df['Trend ctmass mean'] = trend_ctmass_mean_list
master_df['Trend ctmass median'] = trend_ctmass_median_list
master_df['Trend ctmass std'] = trend_ctmass_std_list
master_df['Trend ctmass skewness'] = trend_ctmass_skewness_list 
scaler = MinMaxScaler()               
temp_skew = scaler.fit_transform(np.array(master_df['Trend ctmass skewness']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_skew = pd.DataFrame(temp_skew.flatten())
master_df['Trend ctmass skewness'] = temp_skew
master_df['Trend ctmass kurtosis'] = trend_ctmass_kurtosis_list    
scaler = MinMaxScaler()               
temp_kurtosis = scaler.fit_transform(np.array(master_df['Trend ctmass kurtosis']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_kurtosis = pd.DataFrame(temp_kurtosis.flatten())
master_df['Trend ctmass kurtosis'] = temp_kurtosis

trend_aq_mean_list = []
trend_aq_median_list = []
trend_aq_std_list = []
trend_aq_skewness_list = [] 
trend_aq_kurtosis_list = []
for i in range(0, len(trend_aq_df)):
    trend_aq_mean_list.append(trend_aq_df['Trend aq mean'][i][0])
    trend_aq_median_list.append(trend_aq_df['Trend aq median'][i][0])
    trend_aq_std_list.append(trend_aq_df['Trend aq std'][i][0])
    trend_aq_skewness_list.append(trend_aq_df['Trend aq skewness'][i][0])
    trend_aq_kurtosis_list.append(trend_aq_df['Trend aq kurtosis'][i][0])
master_df['Trend aq mean'] = trend_aq_mean_list
master_df['Trend aq median'] = trend_aq_median_list
master_df['Trend aq std'] = trend_aq_std_list
master_df['Trend aq skewness'] = trend_aq_skewness_list
scaler = MinMaxScaler()               
temp_skew = scaler.fit_transform(np.array(master_df['Trend aq skewness']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_skew = pd.DataFrame(temp_skew.flatten())
master_df['Trend aq skewness'] = temp_skew
master_df['Trend aq kurtosis'] = trend_aq_kurtosis_list 
scaler = MinMaxScaler()               
temp_kurtosis = scaler.fit_transform(np.array(master_df['Trend aq kurtosis']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_kurtosis = pd.DataFrame(temp_kurtosis.flatten())
master_df['Trend aq kurtosis'] = temp_kurtosis

# Noise components here.
summed_noise_conc_mean_list = []
summed_noise_conc_median_list = []
summed_noise_conc_std_list = []
summed_noise_conc_skewness_list = []
summed_noise_conc_kurtosis_list = []
for i in range(0, len(summed_noise_conc_df)):
    summed_noise_conc_mean_list.append(summed_noise_conc_df['Summed noise conc mean'][i][0])
    summed_noise_conc_median_list.append(summed_noise_conc_df['Summed noise conc median'][i][0])
    summed_noise_conc_std_list.append(summed_noise_conc_df['Summed noise conc std'][i][0])
    summed_noise_conc_skewness_list.append(summed_noise_conc_df['Summed noise conc skewness'][i][0])
    summed_noise_conc_kurtosis_list.append(summed_noise_conc_df['Summed noise conc kurtosis'][i][0])
master_df['Summed noise conc mean'] = summed_noise_conc_mean_list
master_df['Summed noise conc median'] = summed_noise_conc_median_list
master_df['Summed noise conc std'] = summed_noise_conc_std_list
master_df['Summed noise conc skewness'] = summed_noise_conc_skewness_list 
scaler = MinMaxScaler()               
temp_skew = scaler.fit_transform(np.array(master_df['Summed noise conc skewness']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_skew = pd.DataFrame(temp_skew.flatten())
master_df['Summed noise conc skewness'] = temp_skew
master_df['Summed noise conc kurtosis'] = summed_noise_conc_kurtosis_list 
scaler = MinMaxScaler()               
temp_kurtosis = scaler.fit_transform(np.array(master_df['Summed noise conc kurtosis']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_kurtosis = pd.DataFrame(temp_kurtosis.flatten())
master_df['Summed noise conc kurtosis'] = temp_kurtosis

summed_noise_ctmass_mean_list = []
summed_noise_ctmass_median_list = []
summed_noise_ctmass_std_list = []
summed_noise_ctmass_skewness_list = []
summed_noise_ctmass_kurtosis_list = []
for i in range(0, len(summed_noise_ctmass_df)):
    summed_noise_ctmass_mean_list.append(summed_noise_ctmass_df['Summed noise ctmass mean'][i][0])
    summed_noise_ctmass_median_list.append(summed_noise_ctmass_df['Summed noise ctmass median'][i][0])
    summed_noise_ctmass_std_list.append(summed_noise_ctmass_df['Summed noise ctmass std'][i][0])
    summed_noise_ctmass_skewness_list.append(summed_noise_ctmass_df['Summed noise ctmass skewness'][i][0])
    summed_noise_ctmass_kurtosis_list.append(summed_noise_ctmass_df['Summed noise ctmass kurtosis'][i][0])
master_df['Summed noise ctmass mean'] = summed_noise_ctmass_mean_list
master_df['Summed noise ctmass median'] = summed_noise_ctmass_median_list
master_df['Summed noise ctmass std'] = summed_noise_ctmass_std_list
master_df['Summed noise ctmass skewness'] = summed_noise_ctmass_skewness_list  
scaler = MinMaxScaler()               
temp_skew = scaler.fit_transform(np.array(master_df['Summed noise ctmass skewness']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_skew = pd.DataFrame(temp_skew.flatten())
master_df['Summed noise ctmass skewness'] = temp_skew
master_df['Summed noise ctmass kurtosis'] = summed_noise_ctmass_kurtosis_list  
scaler = MinMaxScaler()               
temp_kurtosis = scaler.fit_transform(np.array(master_df['Summed noise ctmass kurtosis']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_kurtosis = pd.DataFrame(temp_kurtosis.flatten())
master_df['Summed noise ctmass kurtosis'] = temp_kurtosis

summed_noise_aq_mean_list = []
summed_noise_aq_median_list = []
summed_noise_aq_std_list = []
summed_noise_aq_skewness_list = []
summed_noise_aq_kurtosis_list = []
for i in range(0, len(summed_noise_aq_df)):
    summed_noise_aq_mean_list.append(summed_noise_aq_df['Summed noise aq mean'][i][0])
    summed_noise_aq_median_list.append(summed_noise_aq_df['Summed noise aq median'][i][0])
    summed_noise_aq_std_list.append(summed_noise_aq_df['Summed noise aq std'][i][0])
    summed_noise_aq_skewness_list.append(summed_noise_aq_df['Summed noise aq skewness'][i][0])
    summed_noise_aq_kurtosis_list.append(summed_noise_aq_df['Summed noise aq kurtosis'][i][0])
master_df['Summed noise aq mean'] = summed_noise_aq_mean_list
master_df['Summed noise aq median'] = summed_noise_aq_median_list
master_df['Summed noise aq std'] = summed_noise_aq_std_list
master_df['Summed noise aq skewness'] = summed_noise_aq_skewness_list 
scaler = MinMaxScaler()               
temp_skew = scaler.fit_transform(np.array(master_df['Summed noise aq skewness']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_skew = pd.DataFrame(temp_skew.flatten())
master_df['Summed noise aq skewness'] = temp_skew
master_df['Summed noise aq kurtosis'] = summed_noise_aq_kurtosis_list  
scaler = MinMaxScaler()               
temp_kurtosis = scaler.fit_transform(np.array(master_df['Summed noise aq kurtosis']).reshape(-1,1))      # Scaling skewness and kurtosis.
temp_kurtosis = pd.DataFrame(temp_kurtosis.flatten())
master_df['Summed noise aq kurtosis'] = temp_kurtosis

# Reading lines and doing machine learning for x geospatial visulizations.
viz_num = 0
for i in range(0, len(file_breaks)):
    counter = 0
    original_data_plume = []
    myfile = open(new_directory + '/sgsim_backtr.txt', "r")
    for line in myfile:          
        if counter >= file_breaks[i] and i != 99:                        # Will process first x and last x lines seperate.
            if(counter == file_breaks[i + 1]):
                break
            original_data_plume.append(line) 
        counter += 1
    myfile.close() 
    viz_num += 1

    for i in range(0, len(original_data_plume)):
        original_data_plume[i] = original_data_plume[i].replace('\n', '')
        original_data_plume[i] = original_data_plume[i].split('  ')[1].lstrip()
    
    orig_data_plume_array = np.array(original_data_plume)
    orig_data_plume_array = np.reshape(orig_data_plume_array, (len(X_ax), len(Y_ax), len(Z_ax)), 'F')
    
    # Converting values to float type since they were string.
    orig_data_plume_array = orig_data_plume_array.astype(float) 
    
        
    '''
    # Plotting 2-D contour filled plots.
    generate_2D_contours(X_ax, Y_ax, orig_data_plume_array, namesofmyData, well_name)
    
    # Plotting 3-D contour plots.
    generate_3D_contours(X_ax, Y_ax, orig_data_plume_array)
    '''
    
    # Getting X, Y. and Z locations of wells in our selected wells dataset. 
    X = [];
    Y = [];
    Z = [];
    for i in range(0,len(namesofmyData)):
        for j in range(0,len(well_name)):
            if namesofmyData[i].replace('-Concentration-Noise', '') == well_name[j]:
                X.append(data.get('x')[j])
                Y.append(data.get('y')[j])
                Z.append((data.get('top')[j] + data.get('bottom')[j]) / 2)
                
    # Compute distance from all points to each of the 19 wells X, Y, and Z coords.
    dist = []
    dist = compute_eucid_dist(X_ax, Y_ax, Z_ax, X, Y, Z)
    
    # Computing the concentration inverse-weighted distances for all
    # 19 wells.
    conc_weighted_dist = []
    update_conc_dist = []
    update_conc_dist = compute_inverse_weighted_dist(conc_weighted_dist, 
                                                         update_conc_dist, dist, 
                                                         X_ax, Y_ax, Z_ax, X, Y, Z)
    # Aggregating all concentration inverse-weighted distances for all 19 wells.
    agg_dist = [] 
    total = 0         
    for i in range(0, len(update_conc_dist)):
        if (i % 373749 == 0) & (i != 0):
            agg_dist.append(total)
            print(total)
            total = 0
        total = total + update_conc_dist[i]
            
    # Adding the aggregated distances to the master well dataframe.
    master_df['Concentration Weighted Distances at all elevations in meters' ] = agg_dist
    
    # Retrieving total mass of contamination (sum of concentrations)
    total_concentration_from_plume = []
    radius = 50 # Controls distance in which to search closest points for.
    total_concentration_from_plume = total_mass_contamination_within_radius(total_concentration_from_plume, 
                                                                            radius, X, X_ax, 
                                                                            Y_ax, Z_ax, orig_data_plume_array)
    # Adding the aggregated concentrations within a certain radius to the master well dataframe.
    master_df['Total mass of contamination (sum of concentration) for each well at radius '  + str(radius)] = total_concentration_from_plume

    total_concentration_from_plume_two = []
    radius = 100 # Controls distance in which to search closest points for.
    total_concentration_from_plume_two = total_mass_contamination_within_radius(total_concentration_from_plume_two, 
                                                                            radius, X, X_ax, 
                                                                            Y_ax, Z_ax, orig_data_plume_array)
    # Adding the aggregated concentrations within a certain radius to the master well dataframe.
    master_df['Total mass of contamination (sum of concentration) for each well at radius '  + str(radius)] = total_concentration_from_plume_two

    total_concentration_from_plume_three = []
    radius = 150 # Controls distance in which to search closest points for.
    total_concentration_from_plume_three = total_mass_contamination_within_radius(total_concentration_from_plume_three, 
                                                                                radius, X, X_ax, 
                                                                                Y_ax, Z_ax, orig_data_plume_array)
     # Adding the aggregated concentrations within a certain radius to the master well dataframe.
    master_df['Total mass of contamination (sum of concentration) for each well at radius '  + str(radius)] = total_concentration_from_plume_three
        
    total_concentration_from_plume_four = []
    radius = 200 # Controls distance in which to search closest points for.
    total_concentration_from_plume_four = total_mass_contamination_within_radius(total_concentration_from_plume_four, 
                                                                                radius, X, X_ax, 
                                                                                Y_ax, Z_ax, orig_data_plume_array)
    # Adding the aggregated concentrations within a certain radius to the master well dataframe.
    master_df['Total mass of contamination (sum of concentration) for each well at radius '  + str(radius)] = total_concentration_from_plume_four
        
    '''
    # Plotting closest points to a specifed number of wells in 3-D.
    # Variable well_num must be value between (0-18) since are analyzing 19 extraction wells.
    well_num = 3
    plot_closest_points(X, Y, Z, contour_points_x, contour_points_y, contour_points_z, well_num, radius)
    '''
    
    # Creating the Random forest model and using bootstrapping technique here.
    
    # Define features and target variables.
    # Making all variables related to aqueous rate the input / predictors. Target are alll variables related to ctmass and/or concentration.
    features = master_df[master_df.columns[~master_df.columns.isin(['Total CT Mass', 'Max CT mass', 'Min CT mass', '25th Percentile CT mass',
                                                                      '50th Percentile CT mass', '75th Percentile CT mass', 'STD CT mass',
                                                                      'Summmed seasonal ctmass mean', 'Summmed seasonal ctmass median',
                                                                      'Summmed seasonal ctmass std', 'Summmed seasonal ctmass skewness',
                                                                      'Summmed seasonal ctmass kurtosis', 
                                                                      'Trend ctmass mean',
                                                                      'Trend ctmass median', 'Trend ctmass std', 'Trend ctmass skewness',
                                                                      'Trend ctmass kurtosis', 'Summed noise ctmass mean',
                                                                      'Summed noise ctmass median', 'Summed noise ctmass std',
                                                                      'Summed noise ctmass skewness', 'Summed noise ctmass kurtosis', 
                                                                      'Well Names', 'Total Concentration', 'Max Concentration', 'Min Concentration',
                                                                      '25th Percentile Concentration', '50th Percentile Concentration', 
                                                                      '75th Percentile Concentration', 'STD Conc', 
                                                                      'Summmed seasonal concentration mean',
                                                                      'Summmed seasonal concentration median',
                                                                      'Summmed seasonal concentration std',
                                                                      'Summmed seasonal concentration skewness',
                                                                      'Summmed seasonal concentration kurtosis',
                                                                      'Trend concentration mean', 'Trend concentration median',
                                                                      'Trend concentration std', 'Trend concentration skewness',
                                                                      'Trend concentration kurtosis', 'Summed noise conc mean',
                                                                      'Summed noise conc median', 'Summed noise conc std',
                                                                      'Summed noise conc skewness', 'Summed noise conc kurtosis'])]]

    features_SSA = master_df[master_df.columns[~master_df.columns.isin(['Total CT Mass', 'Max CT mass', 'Min CT mass', '25th Percentile CT mass',
                                                                     '50th Percentile CT mass', '75th Percentile CT mass', 'STD CT mass',
                                                                     'Summmed seasonal ctmass mean', 'Summmed seasonal ctmass median',
                                                                     'Summmed seasonal ctmass std', 'Summmed seasonal ctmass skewness',
                                                                     'Summmed seasonal ctmass kurtosis', 
                                                                     'Trend ctmass mean',
                                                                     'Trend ctmass median', 'Trend ctmass std', 'Trend ctmass skewness',
                                                                     'Trend ctmass kurtosis', 'Summed noise ctmass mean',
                                                                     'Summed noise ctmass median', 'Summed noise ctmass std',
                                                                     'Summed noise ctmass skewness', 'Summed noise ctmass kurtosis', 
                                                                     'Well Names', 'Total Concentration', 'Max Concentration', 'Min Concentration',
                                                                     '25th Percentile Concentration', '50th Percentile Concentration', 
                                                                     '75th Percentile Concentration', 'STD Conc', 
                                                                     'Summmed seasonal concentration mean',
                                                                     'Summmed seasonal concentration median',
                                                                     'Summmed seasonal concentration std',
                                                                     'Summmed seasonal concentration skewness',
                                                                     'Summmed seasonal concentration kurtosis',
                                                                     'Trend concentration mean', 'Trend concentration median',
                                                                     'Trend concentration std', 'Trend concentration skewness',
                                                                     'Trend concentration kurtosis', 'Summed noise conc mean',
                                                                     'Summed noise conc median', 'Summed noise conc std',
                                                                     'Summed noise conc skewness', 'Summed noise conc kurtosis',
                                                                     'Total Aqueous','Max Aqueous', 'Min Aqueous', '25th Percentile Aqueous',
                                                                     '50th Percentile Aqueous', '75th Percentile Aqueous', 'STD Aqueous'])]]
    
    features_without_SSA = master_df[master_df.columns[~master_df.columns.isin(['Total CT Mass', 'Max CT mass', 'Min CT mass', '25th Percentile CT mass',
                                                                       '50th Percentile CT mass', '75th Percentile CT mass', 'STD CT mass',
                                                                       'Summmed seasonal ctmass mean', 'Summmed seasonal ctmass median',
                                                                       'Summmed seasonal ctmass std', 'Summmed seasonal ctmass skewness',
                                                                       'Summmed seasonal ctmass kurtosis', 
                                                                       'Trend ctmass mean',
                                                                       'Trend ctmass median', 'Trend ctmass std', 'Trend ctmass skewness',
                                                                       'Trend ctmass kurtosis', 'Summed noise ctmass mean',
                                                                       'Summed noise ctmass median', 'Summed noise ctmass std',
                                                                       'Summed noise ctmass skewness', 'Summed noise ctmass kurtosis', 
                                                                       'Well Names', 'Total Concentration', 'Max Concentration', 'Min Concentration',
                                                                       '25th Percentile Concentration', '50th Percentile Concentration', 
                                                                       '75th Percentile Concentration', 'STD Conc', 
                                                                       'Summmed seasonal concentration mean',
                                                                       'Summmed seasonal concentration median',
                                                                       'Summmed seasonal concentration std',
                                                                       'Summmed seasonal concentration skewness',
                                                                       'Summmed seasonal concentration kurtosis',
                                                                       'Trend concentration mean', 'Trend concentration median',
                                                                       'Trend concentration std', 'Trend concentration skewness',
                                                                       'Trend concentration kurtosis', 'Summed noise conc mean',
                                                                       'Summed noise conc median', 'Summed noise conc std',
                                                                       'Summed noise conc skewness', 'Summed noise conc kurtosis',
                                                                       'Summmed seasonal aq mean', 'Summmed seasonal aq median',
                                                                       'Summmed seasonal aq std', 'Summmed seasonal aq skewness',
                                                                       'Summmed seasonal aq kurtosis', 'Trend aq mean', 'Trend aq median',
                                                                       'Trend aq std', 'Trend aq skewness', 'Trend aq kurtosis',
                                                                       'Summed noise aq mean', 'Summed noise aq median', 'Summed noise aq std',
                                                                       'Summed noise aq skewness', 'Summed noise aq kurtosis'])]]
                                                                      
                                                                      

    target = master_df[master_df.columns[master_df.columns.isin(['Total CT Mass', 'Max CT mass', 'Min CT mass', '25th Percentile CT mass',
                                                                      '50th Percentile CT mass', '75th Percentile CT mass', 'STD CT mass',
                                                                      'Summmed seasonal ctmass mean', 'Summmed seasonal ctmass median',
                                                                      'Summmed seasonal ctmass std', 'Summmed seasonal ctmass skewness',
                                                                      'Summmed seasonal ctmass kurtosis', 'Trend ctmass mean',
                                                                      'Trend ctmass median', 'Trend ctmass std', 'Trend ctmass skewness',
                                                                      'Trend ctmass kurtosis', 'Summed noise ctmass mean',
                                                                      'Summed noise ctmass median', 'Summed noise ctmass std',
                                                                      'Summed noise ctmass skewness', 'Summed noise ctmass kurtosis'
                                                                      ])]]
    
    target_SSA = master_df[master_df.columns[master_df.columns.isin(['Summmed seasonal ctmass mean', 'Summmed seasonal ctmass median',
                                                                      'Summmed seasonal ctmass std', 'Summmed seasonal ctmass skewness',
                                                                      'Summmed seasonal ctmass kurtosis', 
                                                                      'Trend ctmass mean',
                                                                      'Trend ctmass median', 'Trend ctmass std', 'Trend ctmass skewness',
                                                                      'Trend ctmass kurtosis', 'Summed noise ctmass mean',
                                                                      'Summed noise ctmass median', 'Summed noise ctmass std',
                                                                      'Summed noise ctmass skewness', 'Summed noise ctmass kurtosis'])]]
    
    second_target_w_conc = master_df[master_df.columns[master_df.columns.isin(['Total Concentration', 'Max Concentration', 'Min Concentration',
                                                                        '25th Percentile Concentration', '50th Percentile Concentration', 
                                                                        '75th Percentile Concentration', 'STD Conc', 
                                                                        'Summmed seasonal concentration mean',
                                                                        'Summmed seasonal concentration median',
                                                                        'Summmed seasonal concentration std',
                                                                        'Summmed seasonal concentration skewness',
                                                                        'Summmed seasonal concentration kurtosis',
                                                                        'Trend concentration mean', 'Trend concentration median',
                                                                        'Trend concentration std', 'Trend concentration skewness',
                                                                        'Trend concentration kurtosis', 'Summed noise conc mean',
                                                                        'Summed noise conc median', 'Summed noise conc std',
                                                                        'Summed noise conc skewness', 'Summed noise conc kurtosis',
                                                                        'Total CT Mass', 'Max CT mass', 'Min CT mass', '25th Percentile CT mass',
                                                                        '50th Percentile CT mass', '75th Percentile CT mass', 'STD CT mass',
                                                                        'Summmed seasonal ctmass mean', 'Summmed seasonal ctmass median',
                                                                        'Summmed seasonal ctmass std', 'Summmed seasonal ctmass skewness',
                                                                        'Summmed seasonal ctmass kurtosis', 'Trend ctmass mean',
                                                                        'Trend ctmass median', 'Trend ctmass std', 'Trend ctmass skewness',
                                                                        'Trend ctmass kurtosis', 'Summed noise ctmass mean',
                                                                        'Summed noise ctmass median', 'Summed noise ctmass std',
                                                                        'Summed noise ctmass skewness', 'Summed noise ctmass kurtosis'])]]
    
    directory = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/'
    
    '''
    # Creating training and testing set to see how model initially performs.
    # Predictor: Aqueous rate (GPM) (SSA components and original time-series) 
                 and geostatistical CCl4 concentration (ug/L) spatial variables.

    # Target: CCl4 concentration (ug/L) and CCl4 mass (kg)  
             (SSA and original time-series).
    '''
    # Creating training and testing set to see how model initially performs.
    x_train = features
    y_train = second_target_w_conc
    x_train, x_test, y_train, y_test = train_test_split(x_train, y_train, train_size = 0.7, random_state = 42)
    
    # Evaluating model on training and testing set to find appropriate tree 
    # depth to be used to attempt to avoid overfitting. Also known as 
    # hyperparameter tuning.
    train_scores, test_scores = list(), list()
    # define the tree depths to evaluate
    values = [i for i in range(1, 21)]
    # evaluate a decision tree for each depth
    list_pred = []
    list_actual = []
    list_test = []
    list_test_actual = []
    feat_imp = []
    min_test_rmse = 1
    min_tree_depth = 0
    for i in values:
        # configure the model
        model = RandomForestRegressor(max_depth=i, min_samples_split=6)
        # fit model on the training dataset
        model.fit(x_train, y_train)
        # evaluate on the train dataset
        train_yhat = model.predict(x_train)
        list_pred.append(train_yhat)
        list_actual.append(y_train)
        train_rmse = math.sqrt(mean_squared_error(y_train, train_yhat))
        train_scores.append(train_rmse)
        # evaluate on the test dataset
        test_yhat = model.predict(x_test)
        list_test.append(test_yhat)
        list_test_actual.append(y_test)
        test_rmse = math.sqrt(mean_squared_error(y_test, test_yhat))
        test_scores.append(test_rmse)
        # summarize progress
        print('>%d, train: %.3f, test: %.3f' % (i, train_rmse, test_rmse))
        # feature importance for each tree depth analyzed here.
        feat_imp.append(model.feature_importances_)
        # Gathering the min tree depth value with the lowest rmse.
        if(test_rmse < min_test_rmse):
            min_test_rmse = test_rmse
            min_tree_depth = i
    #plot of train and test scores vs tree depth
    plt.title('Training vs Testing ')
    plt.plot(values, train_scores, '-o', label='Train')
    plt.plot(values, test_scores, '-o', label='Test')
    plt.xlabel('Tree depth')
    plt.ylabel('RMSE')
    plt.legend()
    plt.savefig(directory + '100 GeoSpatial Plots Conc and CTMass All/Geo_Viz_' + str(viz_num) + '_TrainVTest.png')
    plt.show()
    
    ###############################################################################
    # Average feature importance of every tree depth.
    feature_imp_df = pd.DataFrame(feat_imp)
    
    avg_feat_imp = []
    greater_then_thresh_imp = []
    for i in range(0,feature_imp_df.shape[1]):
        avg_feat_imp.append(feature_imp_df.loc[:, i].mean())
        
    # Training model again after determing average feature importance of each feature (greater than 0.04)
    feature_train_df = pd.DataFrame()
    for i in range(0, len(avg_feat_imp)):
        if(avg_feat_imp[i] > 0.04): 
            greater_then_thresh_imp.append(avg_feat_imp[i])
            new_features = features.iloc[:, i]
            feature_train_df[new_features.name] = new_features
    
    # Plotting average feature importance.
    plt.figure(figsize=(20,20))
    plt.bar([x for x in range(feature_train_df.shape[1])], greater_then_thresh_imp)
    plt.title('Feature Importance Barplot')
    plt.ylabel('Feature Importance Score')
    plt.xticks(np.arange(feature_train_df.shape[1]), feature_train_df.columns, rotation = 90)
    plt.savefig(directory + '100 GeoSpatial Plots Conc and CTMass All/Geo_Viz_' + str(viz_num) + '_Avg_Feat_Imp.png')
    plt.show()
    
    ##############################################################################
    # Using features greater than threshold in training set.
    x_train = feature_train_df
    y_train = second_target_w_conc
    x_train, x_test, y_train, y_test = train_test_split(x_train, y_train, train_size = 0.7, random_state = 42)
    
    # Evaluating model on training and testing set to find appropriate tree 
    # depth to be used to attempt to avoid overfitting.
    train_scores, test_scores = list(), list()
    # define the tree depths to evaluate
    values = [i for i in range(1, 21)]
    # evaluate a decision tree for each depth
    list_pred = []
    list_actual = []
    list_test = []
    list_test_actual = []
    feat_imp = []
    min_test_rmse = 1
    min_tree_depth = 0
    for i in values:
        # configure the model
        model = RandomForestRegressor(max_depth=i, min_samples_split = 6)
        # fit model on the training dataset
        model.fit(x_train, y_train)
        # evaluate on the train dataset
        train_yhat = model.predict(x_train)
        list_pred.append(train_yhat)
        list_actual.append(y_train)
        train_rmse = math.sqrt(mean_squared_error(y_train, train_yhat))
        train_scores.append(train_rmse)
        # evaluate on the test dataset
        test_yhat = model.predict(x_test)
        list_test.append(test_yhat)
        list_test_actual.append(y_test)
        test_rmse = math.sqrt(mean_squared_error(y_test, test_yhat))
        test_scores.append(test_rmse)
        # summarize progress
        print('>%d, train: %.3f, test: %.3f' % (i, train_rmse, test_rmse))
        # feature importance for each tree depth analyzed here.
        feat_imp.append(model.feature_importances_)
        if(test_rmse < min_test_rmse):
            min_test_rmse = test_rmse
            min_tree_depth = i
    #plot of train and test scores vs tree depth
    plt.title('Training vs Testing ')
    plt.plot(values, train_scores, '-o', label='Train')
    plt.plot(values, test_scores, '-o', label='Test')
    plt.xlabel('Tree depth')
    plt.ylabel('RMSE')
    plt.legend()
    plt.savefig(directory + '100 GeoSpatial Plots Conc and CTMass All/Geo_Viz_' + str(viz_num) + '_TrainVTest_With_IF_Only.png')
    plt.show()
    
    ##############################################################################
    # Starting bootstrapping procedure.
    # Train random forest ml model. Depth of tree will be the one
    # that best fits the training and testing data witout comprimising the performance
    # of testing set.
    x_train = feature_train_df # Resetting x train and y train to all 19 wells.
    y_train = second_target_w_conc
    reg = RandomForestRegressor(random_state=0, max_depth=min_tree_depth, min_samples_split=6)
    reg.fit(x_train, y_train)
    
    # bootstrap predictions on sampling with replacement dataset.
    rmse = []
    n_iterations = 1000
    mean_perf_measures = []
    median_perf_measures= []
    std_perf_measures = []
    for i in range(n_iterations):
        X_bs, y_bs = resample(x_train, y_train, replace=True)
        # Make predictions
        y_pred = reg.predict(X_bs)  # Predicting on resmapled training data.
        # Evaluate model
        error = math.sqrt(mean_squared_error(y_bs, y_pred)) # Computing rmse
        rmse.append(error)
    # Gathering summary stats for performance measures.
    mean_perf_measures = np.mean(rmse)
    median_perf_measures = np.median(rmse)
    std_perf_measures = np.std(rmse)
    joblib.dump(mean_perf_measures, directory + '100 GeoSpatial Stats Conc and CTMass All/Geo_Viz_' + str(viz_num) + '_Mean.joblib', compress=4)
    joblib.dump(median_perf_measures, directory + '100 GeoSpatial Stats Conc and CTMass All/Geo_Viz_' + str(viz_num) + '_Median.joblib',  compress=4)
    joblib.dump(std_perf_measures, directory + '100 GeoSpatial Stats Conc and CTMass All/Geo_Viz_'+ str(viz_num) +'_Standard_Deviation.joblib', compress=4)
    joblib.dump(rmse, directory + '100 GeoSpatial Stats Conc and CTMass All/Geo_Viz_'+ str(viz_num) +'_RMSE_Dist.joblib', compress=4)
    # get feature importance of random forest model for bootstrapped train.
    importance = reg.feature_importances_
    joblib.dump(importance, directory + '100 GeoSpatial Stats Conc and CTMass All/Geo_Viz_'+ str(viz_num) +'_Boot_FI.joblib', compress=4)
    # summarize feature importance
    for i,v in enumerate(importance):
     print('Feature: %0d, Score: %.5f' % (i,v))
   
    # plot feature importance
    plt.figure(figsize=(20,20))
    plt.bar([x for x in range(len(importance))], importance)
    plt.title('Feature Importance Barplot')
    plt.ylabel('Feature Importance Score')
    plt.xticks(np.arange(feature_train_df.shape[1]), feature_train_df.columns, rotation = 90)
    plt.savefig(directory + '100 GeoSpatial Plots Conc and CTMass All/Geo_Viz_'+ str(viz_num) +'_Feature_Importance_Bootsrapped_Train_Set.png')
    plt.show()
    joblib.dump(feature_train_df, directory + '100 GeoSpatial Stats Conc and CTMass All/Geo_Viz_'+ str(viz_num) +'_Feature_DF.joblib', compress=4)
    
    # plot distribution of mse
    sns.kdeplot(rmse)
    plt.title("RMSE across 1000 bootstrap samples of training set")
    plt.xlabel("RMSE Error")
    plt.show()
    
    # Constructing a confidence interval from the mse error results calculated for 
    # each geostatistical visulization.
    # Get median
    median = np.percentile(rmse, 50)
    joblib.dump(median, directory + '100 GeoSpatial Stats Conc and CTMass All/Geo_Viz_' + str(viz_num) + '_CI_Median.joblib', compress=4)
    
    # Get 95% interval
    alpha = 100-95 # Remember alpha is 100 - percentile to get what percentile we need.
    lower_ci = np.percentile(rmse, alpha/2)
    joblib.dump(lower_ci, directory + '100 GeoSpatial Stats Conc and CTMass All/Geo_Viz_'+ str(viz_num) + '_CI_Lower.joblib', compress=4)
    upper_ci = np.percentile(rmse, 100-alpha/2)
    joblib.dump(upper_ci, directory + '100 GeoSpatial Stats Conc and CTMass All/Geo_Viz_' + str(viz_num)+ '_CI_Upper.joblib', compress=4)
    
    print(f"1000 bootstrapped samples " 
          f"were used to calculate 95% confidence intervals.\n"
          f"Median accuracy is {median:.5f} with a 95% a confidence "
          f"interval of [{lower_ci:.5f},{upper_ci:.5f}].")
    
    sns.kdeplot(rmse)
    plt.title("RMSE across 1000 bootstrap samples of training set (19 wells)\n"
              "showing median with 95 % confidence intervals")
    plt.xlabel("RMSE")
    plt.axvline(median, 0, 14, linestyle="--", color="red")
    plt.axvline(lower_ci, 0, 14, linestyle="--", color="red")
    plt.axvline(upper_ci, 0, 14, linestyle="--", color="red")
    plt.savefig(directory + '100 GeoSpatial Plots Conc and CTMass All/Geo_Viz_' + str(viz_num) + '_RMSE_Distribution_Bootstrapped_Train_Set.png')
    plt.show()
