# -*- coding: utf-8 -*-
"""
Created on Thu May 25 12:51:49 2023

@author: shan594
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import joblib 
from datetime import datetime
from matplotlib import cm
from matplotlib.dates import DateFormatter
import matplotlib.dates as mdates
from temp import SSA
import os
import math as math
import seaborn as sns

# Loading directories and joblib files.
directory = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/'
original_time_series = joblib.load('/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/Rohan_data/Week1/well_ts.joblib')
data = joblib.load('/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/Rohan_data/Week1/well_info.joblib')
test_plume = joblib.load('/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/rohan_plume/Data/2020_CCl4_plume.joblib')
keys_list = list(original_time_series.keys())

# Loading original time series data, well locations, and dates
#for i in original_time_series.keys(): 
num = 24   # This number controls which well concentration time series data to use
current_well_id =  keys_list[num]
time_series_dates = original_time_series.get(keys_list[num]).get('times')
well_concentration = original_time_series.get(keys_list[num]).get('ctet_conc')
well_concentration_mass = original_time_series.get(keys_list[num]).get('ctet_mass')
aqueous = original_time_series.get(keys_list[num]).get('aqueous')

new_dates = pd.to_datetime(time_series_dates)

namesofmyData = []

for filename in os.listdir(directory):
    if filename.endswith("CTAqMass.joblib"):
        namesofmyData.append(filename[:-7])

X = data.get("x")      # Getting X and Y locations of all the wells
Y = data.get("y")    
well_name = data.get("well")

keys_list = list(original_time_series.keys())
id_list = []
for i in keys_list:
    id_list.append(original_time_series.get(i).get('id'))
  
# Getting X and y locations of wells in our selected wells dataset 
# (19 extraction from last year internship due to the others having missing
# data and inconsitencies). 
X = [];
Y = [];
for i in range(0,len(namesofmyData)):
    for j in range(0,len(well_name)):
        if namesofmyData[i].replace('-CTAqMass', '') == well_name[j]:
            X.append(data.get('x')[j])
            Y.append(data.get('y')[j])

fig,ax = plt.subplots(figsize = (12,8))
ax.plot(X, Y, 'o')
ax.set_xlabel("X Coordinates")
ax.set_ylabel("Y Coordinates")
ax.set_title("Current Selected Well Locations for 200 West Area");
for i,txt in enumerate(namesofmyData):
    ax.annotate(namesofmyData[i].replace('-CTAqMass', ''), xy = (X[i], Y[i]))    

# %%
# Plotting all 33 well locations from time series joblib file
# just in case if need be.

X = [];
Y = [];
counter = 0;
for i in range(0,len(keys_list)):
    for j in range(0,len(well_name)):
        if keys_list[i] == well_name[j]:
            X.append(data.get('x')[j])
            Y.append(data.get('y')[j])
            counter+=1;

fig,ax = plt.subplots(figsize = (12,8))
ax.plot(X, Y, 'o')
ax.set_xlabel("X Coordinates")
ax.set_ylabel("Y Coordinates")
ax.set_title("Current Selected Well Locations for 200 West Area");
for i,txt in enumerate(keys_list):
    ax.annotate(keys_list[i], xy = (X[i], Y[i]))    

originalNineteenLy = []
for i,txt in enumerate(namesofmyData):
    originalNineteenLy.append(namesofmyData[i].replace('-CTAqMass', ''))

wellsNotIncLastYear = set(keys_list) - set(originalNineteenLy)
