# -*- coding: utf-8 -*-
"""
Created on Wed Jul  5 15:33:34 2023

@author: shan594
"""
# Imports
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import joblib 
import os
import matplotlib.image as mpimg

# Directories in which we load files.
directory_wo_SSA_Stats = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/100 GeoSpatial Stats/'
directory_w_SSA_Stats = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/100 GeoSpatial Stats SSA Pred/'
directory_w_All_Pred_Stats = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/100 GeoSpatial Stats All Pred/'

directory_wo_SSA_Stats_ctmass_conc = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/100 GeoSpatial Stats Conc and CTMass/'
directory_w_SSA_Stats_ctmass_conc = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/100 GeoSpatial Stats Conc and CTMass SSA Pred/'
directory_w_All_Pred_Stats_ctmass_conc = '/Users/shan594/OneDrive - PNNL/Desktop/InternshipCode-2022/InternshipCode-main/100 GeoSpatial Stats Conc and CTMass All/'

#%%
# Non-SSA predictors results.
# Finding which geostatistical visulization had the highest mean RMSE.
temp_val_m = 0
mean_viz = ''
for filename in os.listdir(directory_wo_SSA_Stats):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_wo_SSA_Stats+filename)
        if(mean > temp_val_m):
            temp_val_m = mean
            mean_viz = directory_wo_SSA_Stats+filename

# Finding which geostatistical visulization had the highest median RMSE.
temp_val_me = 0
median_viz = ''
for filename in os.listdir(directory_wo_SSA_Stats):
    if filename.endswith("Median.joblib") and not filename.endswith("CI_Median.joblib"):
        median = joblib.load(directory_wo_SSA_Stats+filename)
        if(median > temp_val_me):
            temp_val_me = median
            median_viz = directory_wo_SSA_Stats+filename

# Finding which geostatistical visulization had the highest standard deviation RMSE.
temp_val_sd = 0
standard_deviation_viz = ''
for filename in os.listdir(directory_wo_SSA_Stats):
    if filename.endswith("Standard_Deviation.joblib"):
        sd = joblib.load(directory_wo_SSA_Stats+filename)
        if(sd > temp_val_sd):
            temp_val_sd = sd
            standard_deviation_viz = directory_wo_SSA_Stats+filename            

#%%            
# SSA predictors only results.
# Finding which geostatistical visulization had the highest mean RMSE.
temp_val_m = 0
mean_viz = ''
for filename in os.listdir(directory_w_SSA_Stats):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_w_SSA_Stats+filename)
        if(mean > temp_val_m):
            temp_val_m = mean
            mean_viz = directory_w_SSA_Stats+filename

# Finding which geostatistical visulization had the highest median RMSE.
temp_val_me = 0
median_viz = ''
for filename in os.listdir(directory_w_SSA_Stats):
    if filename.endswith("Median.joblib") and not filename.endswith("CI_Median.joblib"):
        median = joblib.load(directory_w_SSA_Stats+filename)
        if(median > temp_val_me):
            temp_val_me = median
            median_viz = directory_w_SSA_Stats+filename

# Finding which geostatistical visulization had the highest standard deviation RMSE.
temp_val_sd = 0
standard_deviation_viz = ''
for filename in os.listdir(directory_w_SSA_Stats):
    if filename.endswith("Standard_Deviation.joblib"):
        sd = joblib.load(directory_w_SSA_Stats+filename)
        if(sd > temp_val_sd):
            temp_val_sd = sd
            standard_deviation_viz = directory_w_SSA_Stats+filename            
            
#%%
# All (SSA and original time-series) predictors results.
# Finding which geostatistical visulization had the highest mean RMSE.
temp_val_m = 0
mean_viz = ''
for filename in os.listdir(directory_w_All_Pred_Stats):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_w_All_Pred_Stats+filename)
        if(mean > temp_val_m):
            temp_val_m = mean
            mean_viz = directory_w_All_Pred_Stats+filename

# Finding which geostatistical visulization had the highest median RMSE.
temp_val_me = 0
median_viz = ''
for filename in os.listdir(directory_w_All_Pred_Stats):
    if filename.endswith("Median.joblib") and not filename.endswith("CI_Median.joblib"):
        median = joblib.load(directory_w_All_Pred_Stats+filename)
        if(median > temp_val_me):
            temp_val_me = median
            median_viz = directory_w_All_Pred_Stats+filename

# Finding which geostatistical visulization had the highest standard deviation RMSE.
temp_val_sd = 0
standard_deviation_viz = ''
for filename in os.listdir(directory_w_All_Pred_Stats):
    if filename.endswith("Standard_Deviation.joblib"):
        sd = joblib.load(directory_w_All_Pred_Stats+filename)
        if(sd > temp_val_sd):
            temp_val_sd = sd
            standard_deviation_viz = directory_w_All_Pred_Stats+filename            
            
#%%            
# Non-SSA predictors results for conc and ctmass as target.
# Finding which geostatistical visulization had the highest mean RMSE.
temp_val_m = 0
mean_viz = ''
for filename in os.listdir(directory_wo_SSA_Stats_ctmass_conc):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_wo_SSA_Stats_ctmass_conc+filename)
        if(mean > temp_val_m):
            temp_val_m = mean
            mean_viz = directory_wo_SSA_Stats_ctmass_conc+filename

# Finding which geostatistical visulization had the highest median RMSE.
temp_val_me = 0
median_viz = ''
for filename in os.listdir(directory_wo_SSA_Stats_ctmass_conc):
    if filename.endswith("Median.joblib") and not filename.endswith("CI_Median.joblib"):
        median = joblib.load(directory_wo_SSA_Stats_ctmass_conc+filename)
        if(median > temp_val_me):
            temp_val_me = median
            median_viz = directory_wo_SSA_Stats_ctmass_conc+filename

# Finding which geostatistical visulization had the highest standard deviation RMSE.
temp_val_sd = 0
standard_deviation_viz = ''
for filename in os.listdir(directory_wo_SSA_Stats_ctmass_conc):
    if filename.endswith("Standard_Deviation.joblib"):
        sd = joblib.load(directory_wo_SSA_Stats_ctmass_conc + filename)
        if(sd > temp_val_sd):
            temp_val_sd = sd
            standard_deviation_viz = directory_wo_SSA_Stats_ctmass_conc + filename            
            
#%%    
# SSA predictors results for conc and ctmass as target.
# Finding which geostatistical visulization had the highest mean RMSE.
temp_val_m = 0
mean_viz = ''
for filename in os.listdir(directory_w_SSA_Stats_ctmass_conc):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_w_SSA_Stats_ctmass_conc+filename)
        if(mean > temp_val_m):
            temp_val_m = mean
            mean_viz = directory_w_SSA_Stats_ctmass_conc+filename

# Finding which geostatistical visulization had the highest median RMSE.
temp_val_me = 0
median_viz = ''
for filename in os.listdir(directory_w_SSA_Stats_ctmass_conc):
    if filename.endswith("Median.joblib") and not filename.endswith("CI_Median.joblib"):
        median = joblib.load(directory_w_SSA_Stats_ctmass_conc+filename)
        if(median > temp_val_me):
            temp_val_me = median
            median_viz = directory_w_SSA_Stats_ctmass_conc+filename

# Finding which geostatistical visulization had the highest standard deviation RMSE.
temp_val_sd = 0
standard_deviation_viz = ''
for filename in os.listdir(directory_w_SSA_Stats_ctmass_conc):
    if filename.endswith("Standard_Deviation.joblib"):
        sd = joblib.load(directory_w_SSA_Stats_ctmass_conc + filename)
        if(sd > temp_val_sd):
            temp_val_sd = sd
            standard_deviation_viz = directory_w_SSA_Stats_ctmass_conc + filename            

#%%
# All (SSA and original time-series) predictor results for conc and ctmass as target.
# Finding which geostatistical visulization had the highest mean RMSE.
temp_val_m = 0
mean_viz = ''
for filename in os.listdir(directory_w_All_Pred_Stats_ctmass_conc):
    if filename.endswith("Mean.joblib"):
        mean = joblib.load(directory_w_All_Pred_Stats_ctmass_conc+filename)
        if(mean > temp_val_m):
            temp_val_m = mean
            mean_viz = directory_w_All_Pred_Stats_ctmass_conc+filename

# Finding which geostatistical visulization had the highest median RMSE.
temp_val_me = 0
median_viz = ''
for filename in os.listdir(directory_w_All_Pred_Stats_ctmass_conc):
    if filename.endswith("Median.joblib") and not filename.endswith("CI_Median.joblib"):
        median = joblib.load(directory_w_All_Pred_Stats_ctmass_conc+filename)
        if(median > temp_val_me):
            temp_val_me = median
            median_viz = directory_w_All_Pred_Stats_ctmass_conc+filename

# Finding which geostatistical visulization had the highest standard deviation RMSE.
temp_val_sd = 0
standard_deviation_viz = ''
for filename in os.listdir(directory_w_All_Pred_Stats_ctmass_conc):
    if filename.endswith("Standard_Deviation.joblib"):
        sd = joblib.load(directory_w_All_Pred_Stats_ctmass_conc + filename)
        if(sd > temp_val_sd):
            temp_val_sd = sd
            standard_deviation_viz = directory_w_All_Pred_Stats_ctmass_conc + filename                      